#!/usr/bin/python
# -*- coding: UTF-8 -*-

import subprocess
import os
import copy

craft_sbox = [0xc, 0xa, 0xd, 0x3, 0xe, 0xb, 0xf, 0x7, 0x8, 0x9, 0x1, 0x5, 0x0, 0x2, 0x4, 0x6]
round_constants = [0x11, 0x84, 0x42, 0x25, 0x96, 0xc7, 0x63, 0xb1, 0x54, 0xa2, 0xd5, 0xe6, 0xf7, 0x73, 0x31, 0x14,\
                   0x82, 0x45, 0x26, 0x97, 0xc3, 0x61, 0xb4, 0x52, 0xa5, 0xd6, 0xe7, 0xf3, 0x71, 0x34, 0x12, 0x85]
tweakey_permutation = [12, 10, 15, 5, 14, 8, 9, 2, 11, 3, 7, 4, 6, 0, 1, 13]
permutation = [15, 12, 13, 14, 10, 9, 8, 11, 6, 5, 4, 7, 1, 2, 3, 0]
MC = [[1, 0, 1, 1], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]]


def header(var1, size):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR({});\n".format(size)
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, round_index, var_size, mul):
    var0 = [["p{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_key_var_dec(var, var_size, mul):
    var0 = [["k{}_{}_{}".format(j, var, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_round_key_var_dec(var, round_index, var_size, mul):
    var0 = [["k{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def single_key_var_dec(var, var_size):
    var0 = ["k_{}_{}".format(var, j) for j in range(0, var_size)]
    return var0


def single_round_key_var_dec(var, round_index, var_size):
    var0 = ["k_{}_{}_{}".format(var, round_index, j) for j in range(0, var_size)]
    return var0


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver1(solve_file):
    stp_parameters = ["stp", "--cryptominisat", "--thread", "6", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def __xor_operate_branch(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        if var_out[var_index] == "0bin0000":
            xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
        else:
            xor_statement += "ASSERT((BVXOR({0}, {1}))[3:3]|(BVXOR({0}, {1}))[2:2]|(BVXOR({0}, {1}))[1:1]|(BVXOR({0}, {1}))[0:0] = 0bin1);\n".format(var_in1[var_index], var_in2[var_index])
    return xor_statement


def __xor_operate_detail(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
    return xor_statement


def xor_operate(var1, var2, values, mode):
    if mode == "branch":
        return __xor_operate_branch(var1, var2, values)
    elif mode == "detail":
        return __xor_operate_detail(var1, var2, values)
    else:
        print("Input format error!")


def perm_wire_in(var1, perm):
    var = ["" for ii in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[i] = var1[perm[i]]
    return var


def perm_wire_out(var1, perm):
    var = ["" for ii in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[perm[i]] = var1[i]
    return var


def __xor_two_operation(var_in1, var_in2, var_out):
    xor_statement = ""
    for i in range(0, len(var_in1)):
        xor_statement += "ASSERT({} = BVXOR({}, {}));\n".format(var_out[i], var_in1[i], var_in2[i])
    return xor_statement


def related_tweakeys_schedule(k0, k1, t, tk, mul):
    statement = ""
    for m in range(0, mul):
        statement += __xor_two_operation(k0[m], t[m], tk[0][m])
        statement += __xor_two_operation(k1[m], t[m], tk[1][m])
        var1 = copy.deepcopy(perm_wire_in(t[m], tweakey_permutation))
        statement += __xor_two_operation(k0[m], var1, tk[2][m])
        statement += __xor_two_operation(k1[m], var1, tk[3][m])
    return statement


def single_tweakeys_schedule(k0, k1, t, tk):
    statement = ""
    statement += __xor_two_operation(k0, t, tk[0])
    statement += __xor_two_operation(k1, t, tk[1])
    var1 = copy.deepcopy(perm_wire_in(t, tweakey_permutation))
    statement += __xor_two_operation(k0, var1, tk[2])
    statement += __xor_two_operation(k1, var1, tk[3])
    return statement


def __sbox_operate_4bits(var_in, var_out, sbox):
    statement1 = "0bin1100"
    for i in range(1, 16):
        iv = "0bin"
        for j1 in range(0, 4):
            iv += "{}".format((i >> (3-j1)) & 0x1)
        siv = "0bin"
        for j in range(0, 4):
            siv += "{}".format((sbox[i] >> (3-j)) & 0x1)
        statement1 = "(IF {} = {} THEN {} ELSE {} ENDIF)".format(var_in, iv, siv, statement1)
    statement = "ASSERT({} = {});\n".format(var_out, statement1)
    return statement


def subcells_operation(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(0, len(var_in[m])):
            statement += __sbox_operate_4bits(var_in[m][i], var_out[m][i], craft_sbox)
    return statement


def add_constants_and_tweakey_operation(var_in, round_constant, tweakey, var_out):
    statement = ""
    for i in range(0, len(var_in)):
        if i == 4:
            statement += "ASSERT({} = BVXOR({}, BVXOR({}, 0bin{})));\n".format(var_out[i], var_in[i], tweakey[i], "{:0>8b}".format(round_constant)[0:4])
        elif i == 5:
            statement += "ASSERT({} = BVXOR({}, BVXOR({}, 0bin{})));\n".format(var_out[i], var_in[i], tweakey[i], "{:0>8b}".format(round_constant)[4:8])
        else:
            statement += "ASSERT({} = BVXOR({}, {}));\n".format(var_out[i], var_in[i], tweakey[i])
    return statement


def mixcolumns_operation(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(0, len(var_in[m])):
            if i in {0, 1, 2, 3}:
                statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var_out[m][i], var_in[m][i], var_in[m][i+8], var_in[m][i+12])
            elif i in {4, 5, 6, 7}:
                statement += "ASSERT({} = BVXOR({}, {}));\n".format(var_out[m][i], var_in[m][i], var_in[m][i+8])
            else:
                statement += "ASSERT({} = {});\n".format(var_out[m][i], var_in[m][i])
    return statement


def __constraint_func(var_in, var_out, positions, mul):
    statement = ""
    for m in range(1, mul):
        for i in range(len(var_in[0])):
            if i in positions:
                statement += "ASSERT(BVXOR({}, BVXOR({}, BVXOR({}, {}))) = 0bin0000);\n".format(
                    var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i]
                )
    return statement


def __constraint_func_or(var_in, var_out, values, mul):
    statement = ""
    for m in range(1, mul):
        tmp = "ASSERT(0bin0000"
        for i in range(len(var_in[0])):
            if i in values:
                tmp += "|(BVXOR({}, BVXOR({}, BVXOR({}, {}))))".format(var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i])
        tmp += " = 0bin0000);\n"
        statement += tmp
    return statement


def related_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    tweakeys = list()
    key_values = list()

    k0 = related_key_var_dec("k0", cd["block_size"], cd["mul"])
    k1 = related_key_var_dec("k1", cd["block_size"], cd["mul"])
    t = related_key_var_dec("t", cd["block_size"], cd["mul"])
    tk1 = related_key_var_dec("tk1", cd["block_size"], cd["mul"])
    tk2 = related_key_var_dec("tk2", cd["block_size"], cd["mul"])
    tk3 = related_key_var_dec("tk3", cd["block_size"], cd["mul"])
    tk4 = related_key_var_dec("tk4", cd["block_size"], cd["mul"])
    tweakeys.append((copy.deepcopy(tk1)))
    tweakeys.append((copy.deepcopy(tk2)))
    tweakeys.append((copy.deepcopy(tk3)))
    tweakeys.append((copy.deepcopy(tk4)))
    key_values.append(copy.deepcopy(k0))
    key_values.append(copy.deepcopy(k1))
    key_values.append(copy.deepcopy(t))
    all_var += copy.deepcopy(k0)
    all_var += copy.deepcopy(k1)
    all_var += copy.deepcopy(t)
    all_var += copy.deepcopy(tk1)
    all_var += copy.deepcopy(tk2)
    all_var += copy.deepcopy(tk3)
    all_var += copy.deepcopy(tk4)
    statement += related_tweakeys_schedule(k0, k1, t, tweakeys, cd["mul"])

    x = state_var_dec("x", round_inf[0], cd["block_size"], cd["mul"])
    begin_values = copy.deepcopy(x)

    for rou in range(round_inf[0], round_inf[1]):
        all_var += copy.deepcopy(x)
        y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(y)
        z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        tmp = list()
        for m in range(0, cd["mul"]):
            statement += add_constants_and_tweakey_operation(x[m], round_constants[rou], tweakeys[(rou+round_inf[0]) % 4][m], y[m])
            tmp.append(copy.deepcopy(perm_wire_in(y[m], permutation)))
        if (rou + 1) == round_inf[2]:
            w = state_var_dec("w", rou + 1, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(w)
            statement += subcells_operation(tmp, w, cd["mul"])
            if cd["flag"] == "contraction":
                statement += __constraint_func(w, z, cd["positions"], cd["mul"])
            else:
                statement += __constraint_func_or(w, z, cd["positions"], cd["mul"])
        else:
            statement += subcells_operation(tmp, z, cd["mul"])
        x1 = state_var_dec("x", rou + 1, cd["block_size"], cd["mul"])
        statement += mixcolumns_operation(z, x1, cd["mul"])
        x = copy.deepcopy(x1)
    y = state_var_dec("y", round_inf[1], cd["block_size"], cd["mul"])
    all_var += copy.deepcopy(x)
    all_var += copy.deepcopy(y)
    for m in range(0, cd["mul"]):
        statement += add_constants_and_tweakey_operation(x[m], round_constants[round_inf[1]], tweakeys[round_inf[1] % 4][m], y[m])
    end_values = copy.deepcopy(y)
    return begin_values, end_values, key_values, all_var, statement


def single_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    tweakeys = list()

    k0 = single_key_var_dec("k0", cd["block_size"])
    k1 = single_key_var_dec("k1", cd["block_size"])
    t = single_key_var_dec("t", cd["block_size"])
    tk1 = single_key_var_dec("tk1", cd["block_size"])
    tk2 = single_key_var_dec("tk2", cd["block_size"])
    tk3 = single_key_var_dec("tk3", cd["block_size"])
    tk4 = single_key_var_dec("tk4", cd["block_size"])
    tweakeys.append((copy.deepcopy(tk1)))
    tweakeys.append((copy.deepcopy(tk2)))
    tweakeys.append((copy.deepcopy(tk3)))
    tweakeys.append((copy.deepcopy(tk4)))
    all_var.append(copy.deepcopy(k0))
    all_var.append(copy.deepcopy(k1))
    all_var.append(copy.deepcopy(t))
    all_var.append(copy.deepcopy(tk1))
    all_var.append(copy.deepcopy(tk2))
    all_var.append(copy.deepcopy(tk3))
    all_var.append(copy.deepcopy(tk4))
    statement += single_tweakeys_schedule(k0, k1, t, tweakeys)

    x = state_var_dec("x", round_inf[0], cd["block_size"], cd["mul"])
    begin_values = copy.deepcopy(x)

    for rou in range(round_inf[0], round_inf[1]):
        all_var += copy.deepcopy(x)
        y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(y)
        z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        tmp = list()
        for m in range(0, cd["mul"]):
            tmp.append(copy.deepcopy(perm_wire_in(x[m], permutation)))
        if (rou+1) == round_inf[2]:
            w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(w)
            statement += subcells_operation(tmp, w, cd["mul"])
            if cd["flag"] == "contraction":
                statement += __constraint_func(w, y, cd["positions"], cd["mul"])
            else:
                statement += __constraint_func_or(w, y, cd["positions"], cd["mul"])
        else:
            statement += subcells_operation(tmp, y, cd["mul"])
        statement += mixcolumns_operation(y, z, cd["mul"])
        x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
        for m in range(0, cd["mul"]):
            statement += add_constants_and_tweakey_operation(z[m], round_constants[rou], tweakeys[rou % 4], x1[m])
        x = copy.deepcopy(x1)

    all_var += copy.deepcopy(x)
    y = state_var_dec("y", round_inf[1], cd["block_size"], cd["mul"])
    all_var += copy.deepcopy(y)
    tmp = list()
    for m in range(0, cd["mul"]):
        tmp.append(copy.deepcopy(perm_wire_in(x[m], permutation)))
    statement += subcells_operation(tmp, y, cd["mul"])
    end_values = copy.deepcopy(y)

    return begin_values, end_values, all_var, statement


def __mb_mode1(cd, round_inf):
    statement = ""
    statement1 = ""
    begin_values = list()
    end_values = list()

    if cd["scenario"] == "RK":
        begin_values, end_values, key_values, all_var, statement1 = related_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var, cd["sbox_size"])
        for index in range(0, len(key_values)):
            for i in range(1, cd["mul"]):
                statement += xor_operate(key_values[index][0], key_values[index][i], cd["k{}_{}".format(index+1, i)], cd["mode"][1])
    elif cd["scenario"] == "SK":
        begin_values, end_values, all_var, statement1 = single_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var, cd["sbox_size"])

    else:
        print("The scenario is invalid.")

    for i in range(1, cd["mul"]):
        statement += xor_operate(begin_values[0], begin_values[i], cd["b{}".format(i)], cd["mode"][1])

    statement += statement1

    for i in range(1, cd["mul"]):
        statement += xor_operate(end_values[0], end_values[i], cd["e{}".format(i)], cd["mode"][1])

    statement += trailer([], [])

    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __mb_mode1(cd, round_inf)


