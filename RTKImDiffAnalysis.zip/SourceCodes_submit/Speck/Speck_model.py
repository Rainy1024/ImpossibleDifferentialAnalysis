#!/usr/bin/python
# -*- coding: UTF-8 -*-


import copy
import os
import subprocess


def header(var1, size):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR({});\n".format(size)
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, rou, mul, var_size):
    var = [["p{}_{}_{}_{}".format(j, var, rou, i) for j in range(0, mul)] for i in range(0, var_size)]
    return var


def key_var_dec(var, round_inf):
    var = ["{}_{}".format(var, rou) for rou in range(round_inf[0], round_inf[1])]
    return var


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver1(solve_file):
    stp_parameters = ["stp", "--cryptominisat", "--thread", "6", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver_val(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return 1
    else:
        return 0


def getStringLeftRotate(value, rotation, wordsize):
    if rotation % wordsize == 0:
        return "{0}".format(value)
    statement1 = "((({0} << {1})[{2}:0]) | (({0} >> {3})[{2}:0]))".format(
        value, (rotation % wordsize), wordsize-1, (wordsize - rotation) % wordsize)

    return statement1


def getStringRightRotate(value, rotation, wordsize):
    if rotation % wordsize == 0:
        return "{0}".format(value)
    statement1 = "((({0} >> {1})[{2}:0]) | (({0} << {3})[{2}:0]))".format(
        value, (rotation % wordsize), wordsize-1, (wordsize - rotation) % wordsize)
    return statement1


def getStringAddition(var_in1, var_in2, var_out, wordsize, alpha, mul):
    statement1 = ""
    for m in range(0, mul):
        statement1 += "ASSERT({} = BVPLUS({}, {}, {}));\n".format(
            var_out[m], wordsize, getStringRightRotate(var_in1[m], alpha, wordsize), var_in2[m]
        )
    return statement1


def getConditionConstraints(var_inl, var_outl, var_inr, var_outr, positions, wordsize):
    statement = ""
    for i in range(0, wordsize):
        if i in positions:
            statement += "ASSERT(BVXOR({0}[{4}:{4}], BVXOR({1}[{4}:{4}], BVXOR({2}[{4}:{4}], {3}[{4}:{4}]))) = 0bin0);\n".format(
                var_inr[0], var_inr[1], var_outr[0], var_outr[1], i
            )
    for j in range(wordsize, 2*wordsize):
        if j in positions:
            statement += "ASSERT(BVXOR({0}[{4}:{4}], BVXOR({1}[{4}:{4}], BVXOR({2}[{4}:{4}], {3}[{4}:{4}]))) = 0bin0);\n".format(
                var_inl[0], var_inl[1], var_outl[0], var_outl[1], j-wordsize
            )
    return statement


def __xor_2values_func(var_in1, var_in2, var_out, mul):
    statement = ""
    for m in range(0, mul):
        statement += "ASSERT({} = BVXOR({}, {}));\n".format(var_out[m], var_in1[m], var_in2[m])
    return statement


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def xor_operate(var1, var2, var3):
    xor_statement = ""
    for var_index in range(0, len(var1)):
        xor_statement += __xor_operate_1(var1[var_index], var2[var_index], var3[var_index])
    return xor_statement


def values_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    x = state_var_dec("x", round_inf[0], cd["mul"], 2)
    begin_values = copy.deepcopy(x)
    k = key_var_dec("k", [round_inf[0], round_inf[1]+1])
    w = key_var_dec("w", round_inf)
    l = key_var_dec("l", [0, round_inf[1]+cd["key_words"]-1])
    all_var.append(copy.deepcopy(k))
    all_var.append(copy.deepcopy(w))
    all_var.append(copy.deepcopy(l))

    for rou in range(round_inf[0], round_inf[1]):
        y = state_var_dec("y", rou, cd["mul"], 1)
        all_var += copy.deepcopy(x+y)
        statement += getStringAddition(x[0], x[1], y[0], cd["word_size"], cd["shift"][0], cd["mul"])
        x1 = state_var_dec("x", rou+1, cd["mul"], 2)
        if (rou+1) == round_inf[2]:
            z = state_var_dec("z", rou+1, cd["mul"], 2)
            all_var += copy.deepcopy(z)
            statement += __xor_2values_func(y[0], [k[rou], k[rou]], z[0], cd["mul"])
            tmp = list()
            for m in range(cd["mul"]):
                tmp.append(copy.deepcopy(getStringLeftRotate(x[1][m], cd["shift"][1], cd["word_size"])))
            statement += __xor_2values_func(tmp, z[0], z[1], cd["mul"])
            statement += getConditionConstraints(z[0], x1[0], z[1], x1[1], cd["positions"], cd["word_size"])

        else:
            statement += __xor_2values_func(y[0], [k[rou], k[rou]], x1[0], cd["mul"])
            tmp = list()
            for m in range(cd["mul"]):
                tmp.append(copy.deepcopy(getStringLeftRotate(x[1][m], cd["shift"][1], cd["word_size"])))
            statement += __xor_2values_func(tmp, x1[0], x1[1], cd["mul"])
        x = copy.deepcopy(x1)

        statement += "ASSERT({} = BVPLUS({}, {}, {}));\n".format(
            w[rou], cd["word_size"], getStringRightRotate(l[rou], cd["shift"][0], cd["word_size"]), k[rou]
        )
        statement += "ASSERT({} = BVXOR({}, {}));\n".format(l[rou+cd["key_words"]-1], w[rou], "0bin{:0>16b}".format(rou))
        statement += "ASSERT({} = BVXOR({}, {}));\n".format(
            k[rou+1], getStringLeftRotate(k[rou], cd["shift"][1], cd["word_size"]), l[rou+cd["key_words"]-1]
        )
    all_var += copy.deepcopy(x)
    end_values = copy.deepcopy(x)

    return begin_values, end_values, all_var, statement


def __model_build_func(cd, round_inf):
    statement = ""
    begin_values, end_values, all_var, statement1 = values_propagate_phrase(cd, round_inf)

    statement += header(all_var, cd["word_size"])

    for i in range(1, cd["mul"]):
        statement += "ASSERT(BVXOR({}, {}) = {});\n".format(begin_values[0][0], begin_values[0][i], cd["bl{}".format(i)])

    for i in range(1, cd["mul"]):
        statement += "ASSERT(BVXOR({}, {}) = {});\n".format(begin_values[1][0], begin_values[1][i], cd["br{}".format(i)])

    statement += statement1

    for i in range(1, cd["mul"]):
        statement += "ASSERT(BVXOR({}, {}) = {});\n".format(end_values[0][0], end_values[0][i], cd["el{}".format(i)])

    for i in range(1, cd["mul"]):
        statement += "ASSERT(BVXOR({}, {}) = {});\n".format(end_values[1][0], end_values[1][i], cd["er{}".format(i)])

    statement += trailer([], [])

    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __model_build_func(cd, round_inf)




