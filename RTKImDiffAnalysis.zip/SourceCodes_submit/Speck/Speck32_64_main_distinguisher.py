#!/usr/bin/python
# -*- coding: UTF-8 -*-

import copy
import Speck_model
import time
import os

if __name__ == "__main__":

    cd = dict()

    cd["cipher_name"] = "speck32_64"

    cd["mul"] = 2
    cd["block"] = 2
    cd["word_size"] = 16
    cd["key_words"] = 4
    cd["key_size"] = 64
    cd["shift"] = [7, 2]

    cd["mode"] = 'ID'

    folder = cd["cipher_name"] + "_{}way_{}_record".format(cd["mul"], cd["mode"])

    if not os.path.exists(folder):
        os.mkdir(folder)

    position_space = list()
    for i in range(0, 32):
        position_space.append([copy.deepcopy(i)])

    round_i = 6
    cd["position_rou"] = 1
    cd["record_file"] = folder + "////" + cd["cipher_name"] + "_record_{}.txt".format(cd["mode"])
    cd["time_record"] = folder + "////" + cd["cipher_name"] + "_time_record_{}.txt".format(cd["mode"])
    cd["result_file"] = folder + "////" + cd["cipher_name"] + "_result_record_{}.txt".format(cd["mode"])
    total_search = len(position_space)
    ttt1 = time.time()

    # cd["bl1"] = copy.deepcopy("0bin0000000000001000")
    # cd["br1"] = copy.deepcopy("0bin0000000000000000")
    # cd["el1"] = copy.deepcopy("0bin1000000000000000")
    # cd["er1"] = copy.deepcopy("0bin1000000000000010")

    # cd["bl1"] = copy.deepcopy("0bin0000000000011000")
    # cd["br1"] = copy.deepcopy("0bin0000000000000000")
    # cd["el1"] = copy.deepcopy("0bin1000000000000000")
    # cd["er1"] = copy.deepcopy("0bin1000000000000010")

    cd["bl1"] = copy.deepcopy("0bin0000000000111000")
    cd["br1"] = copy.deepcopy("0bin0000000000000000")
    cd["el1"] = copy.deepcopy("0bin1000000000000000")
    cd["er1"] = copy.deepcopy("0bin1000000000000010")

    rf = open(cd["record_file"], "a")
    rf.write("{}\n".format("*" * 20))
    rf.write("when the values:\n")
    rf.write("bl = {}\n".format(str(cd["bl1"])))
    rf.write("br = {}\n".format(str(cd["br1"])))
    rf.write("el = {}\n".format(str(cd["el1"])))
    rf.write("er = {}\n".format(str(cd["er1"])))
    rf.close()

    while cd["position_rou"] < round_i:
        cd["solve_file"] = folder + "////" + cd["cipher_name"] + "_round{}.stp".format(round_i)
        t1 = time.time()
        distinguish_find = False
        search_count = 0
        for s in position_space:
            cd["positions"] = copy.deepcopy(s)
            mode = [cd["mode"], [0, round_i]]
            t11 = time.time()
            Speck_model.model_build(cd, mode)
            flag = Speck_model.solver(cd["solve_file"])
            search_count += 1
            t22 = time.time()
            print(t22 - t11)
            if flag:
                rf = open(cd["record_file"], "a")
                rf.write("*" * 20)
                rf.write("{}round impossible {}way distinguisher found in round{} with contradiction in {}\n".format(
                    round_i, cd["mul"], cd["position_rou"], cd["positions"])
                )
                rf.write("round = {}, lp = {}\n".format(str(cd["position_rou"]), str(cd["positions"])))
                rf.close()
                distinguish_find = True
                continue
            else:
                print("testing: position = {}\nround = {}, search = {}, total_search = {}.".format(
                    cd["positions"], cd["position_rou"], search_count, total_search))

        t2 = time.time()
        cd["position_rou"] += 1
        tf = open(cd["time_record"], "a")
        if distinguish_find:
            tf.write("After " + str(t2 - t1) + "time, we found {} rounds impossible differential with contradiction in round{}.\n\n".format(round_i, cd["position_rou"]-1))
        else:
            tf.write("After " + str(t2 - t1) + "time, we show no {} round impossible differential with contradiction in round{}.\n\n".format(round_i, cd["position_rou"]-1))
        tf.close()