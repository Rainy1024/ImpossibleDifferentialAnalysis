#!/usr/bin/python
# -*- coding: UTF-8 -*-

import subprocess
import os
import copy

sbox = [0xc, 0xa, 0xd, 0x3, 0xe, 0xb, 0xf, 0x7, 0x8, 0x9, 0x1, 0x5, 0x0, 0x2, 0x4, 0x6]
round_constants = [[0x1, 0x3, 0x1, 0x9, 0x8, 0xa, 0x2, 0xe, 0x0, 0x3, 0x7, 0x0, 0x7, 0x3, 0x4, 0x4],\
                   [0xa, 0x4, 0x0, 0x9, 0x3, 0x8, 0x2, 0x2, 0x2, 0x9, 0x9, 0xf, 0x3, 0x1, 0xd, 0x0],\
                   [0x0, 0x8, 0x2, 0xe, 0xf, 0xa, 0x9, 0x8, 0xe, 0xc, 0x4, 0xe, 0x6, 0xc, 0x8, 0x9],\
                   [0x4, 0x5, 0x2, 0x8, 0x2, 0x1, 0xe, 0x6, 0x3, 0x8, 0xd, 0x0, 0x1, 0x3, 0x7, 0x7],\
                   [0xb, 0xe, 0x5, 0x4, 0x6, 0x6, 0xc, 0xf, 0x3, 0x4, 0xe, 0x9, 0x0, 0xc, 0x6, 0xc],\
                   [0xc, 0x0, 0xa, 0xc, 0x2, 0x9, 0xb, 0x7, 0xc, 0x9, 0x7, 0xc, 0x5, 0x0, 0xd, 0xd],\
                   [0x3, 0xf, 0x8, 0x4, 0xd, 0x5, 0xb, 0x5, 0xb, 0x5, 0x4, 0x7, 0x0, 0x9, 0x1, 0x7],\
                   [0x9, 0x2, 0x1, 0x6, 0xd, 0x5, 0xd, 0x9, 0x8, 0x9, 0x7, 0x9, 0xf, 0xb, 0x1, 0xb]]

tweak_permutation = [6, 5, 14, 15, 0, 1, 2, 3, 7, 12, 13, 4, 8, 9, 10, 11]
inv_tweak_permutation = [4, 5, 6, 7, 11, 1, 0, 8, 12, 13, 14, 15, 9, 10, 2, 3]
permutation = [0, 11, 6, 13, 10, 1, 12, 7, 5, 14, 3, 8, 15, 4, 9, 2]
inv_permutation = [0, 5, 15, 10, 13, 8, 2, 7, 11, 14, 4, 1, 6, 3, 9, 12]
alpha = [0x2, 0x4, 0x3, 0xf, 0x6, 0xa, 0x8, 0x8, 0x8, 0x5, 0xa, 0x3, 0x0, 0x8, 0xd, 0x3]


def header(var1, size):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR({});\n".format(size)
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, round_index, var_size, mul):
    var0 = [["p{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_key_var_dec(var, var_size, mul):
    var0 = [["k{}_{}_{}".format(j, var, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_round_key_var_dec(var, round_index, var_size, mul):
    var0 = [["k{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def single_key_var_dec(var, var_size):
    var0 = ["k_{}_{}".format(var, j) for j in range(0, var_size)]
    return var0


def single_round_key_var_dec(var, round_index, var_size):
    var0 = ["k_{}_{}_{}".format(var, round_index, j) for j in range(0, var_size)]
    return var0


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def __xor_operate_branch(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        if var_out[var_index] == "0bin0000":
            xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
        else:
            xor_statement += "ASSERT((BVXOR({0}, {1}))[3:3]|(BVXOR({0}, {1}))[2:2]|(BVXOR({0}, {1}))[1:1]|(BVXOR({0}, {1}))[0:0] = 0bin1);\n".format(var_in1[var_index], var_in2[var_index])
    return xor_statement


def __xor_operate_detail(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
    return xor_statement


def xor_operate(var1, var2, values, mode):
    if mode == "branch":
        return __xor_operate_branch(var1, var2, values)
    elif mode == "detail":
        return __xor_operate_detail(var1, var2, values)
    else:
        print("Input format error!")


def perm_wire_in(var1, perm):
    var = ["" for i in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[i] = var1[perm[i]]
    return var


def perm_wire_out(var1, perm):
    var = ["" for i in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[perm[i]] = var1[i]
    return var


def round_key_schdule(var_in, var_out):
    statement = ""
    statement += "ASSERT({0} = {1}[0:0]@{2}[3:3]@{2}[2:2]@{2}[1:1]);\n".format(var_out[0], var_in[15], var_in[0])
    for i in range(1, len(var_in)-1):
        statement += "ASSERT({0} = {1}[0:0]@{2}[3:3]@{2}[2:2]@{2}[1:1]);\n".format(var_out[i], var_in[i-1], var_in[i])
    statement += "ASSERT({0} = {1}[0:0]@{2}[3:3]@{2}[2:2]@(BVXOR({3}[3:3], {4}[1:1])));\n".format(var_out[15], var_in[14], var_in[15], var_in[15], var_in[0])
    return statement


def __sbox_operation(var_in, var_out):
    sbox = [0xc, 0xa, 0xd, 0x3, 0xe, 0xb, 0xf, 0x7, 0x8, 0x9, 0x1, 0x5, 0x0, 0x2, 0x4, 0x6]
    statement1 = "0bin1100"
    for i in range(1, 16):
        iv = "0bin"
        for j in range(0, 4):
            iv += "{}".format((i >> (3 - j)) & 0x1)
        siv = "0bin"
        for j in range(0, 4):
            siv += "{}".format((sbox[i] >> (3 - j)) & 0x1)
        statement1 = "(IF {} = {} THEN {} ELSE {} ENDIF)".format(var_in, iv, siv, statement1)
    statement = "ASSERT({} = {});\n".format(var_out, statement1)
    return statement


def subcells_operation(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(0, len(var_in[m])):
            statement += __sbox_operation(var_in[m][i], var_out[m][i])
    return statement


def add_constants_and_tweakey_operation(var_in, var_out, constants, tweakey, roundkey):
    statement = ""
    var = copy.deepcopy(perm_wire_out(var_out, permutation))
    for i in range(0, len(var_in)):
        iv = "0bin"
        for j in range(0, 4):
            iv += "{}".format((constants[i] >> (3 - j)) & 0x1)
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, {}))));\n".format(
            var[i], tweakey[i], roundkey[i], iv, var_in[i]
        )
    return statement


def inv_add_constants_and_tweakey_operation(var_in, var_out, constants, tweakey, roundkey):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, permutation))
    for i in range(0, len(var_in)):
        iv = "0bin"
        siv = "0bin"
        for j in range(0, 4):
            iv += "{}".format((constants[i] >> (3 - j)) & 0x1)
            siv += "{}".format((alpha[i] >> (3 - j)) & 0x1)
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, BVXOR({}, {})))));\n".format(
            var_out[i], tweakey[i], roundkey[i], siv, iv, var[i]
        )
    return statement


def tweakey_schedule(var_in, var_out):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, tweak_permutation))
    for i in range(len(var_in)):
        statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def inv_tweakey_schedule(var_in, var_out):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, inv_tweak_permutation))
    for i in range(len(var_in)):
        statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def mixcolumns_operation(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(0, len(var_in[m])):
            if i in {0, 1, 2, 3}:
                statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var_out[m][i], var_in[m][i+4], var_in[m][i+8], var_in[m][i+12])
            elif i in {4, 5, 6, 7}:
                statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var_out[m][i], var_in[m][i-4], var_in[m][i+4], var_in[m][i+8])
            elif i in {8, 9, 10, 11}:
                statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var_out[m][i], var_in[m][i-8], var_in[m][i-4], var_in[m][i+4])
            else:
                statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var_out[m][i], var_in[m][i-12], var_in[m][i-8], var_in[m][i-4])
    return statement


def __constraint_func(var_in, var_out, positions, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(len(var_in[0])):
            if i in positions:
                statement += "ASSERT(BVXOR({}, BVXOR({}, BVXOR({}, {}))) = 0bin0000);\n".format(
                    var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i]
                )
    return statement


def __constraint_func_or(var_in, var_out, values, mul):
    statement = ""
    for m in range(1, mul):
        tmp = "ASSERT(0bin0000"
        for i in range(len(var_in[0])):
            if i in values:
                tmp += "|(BVXOR({}, BVXOR({}, BVXOR({}, {}))))".format(var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i])
        tmp += " = 0bin0000);\n"
        statement += tmp
    return statement


def related_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    key_values = list()

    rk = related_key_var_dec("rk", cd["block_size"], cd["mul"])
    all_var += copy.deepcopy(rk)
    tk = related_round_key_var_dec("tk", round_inf[0], cd["block_size"], cd["mul"])
    key_values.append(copy.deepcopy(rk))
    key_values.append(copy.deepcopy(tk))

    x = state_var_dec("x", round_inf[0], cd["block_size"], cd["mul"])
    begin_values = copy.deepcopy(x)

    for rou in range(round_inf[0], round_inf[1]):

        if rou < 7:
            all_var += copy.deepcopy(tk)
            all_var += copy.deepcopy(x)
            y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(y)
            z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(z)

            for m in range(0, cd["mul"]):
                statement += add_constants_and_tweakey_operation(x[m], y[m], round_constants[rou], tk[m], rk[m])
            statement += mixcolumns_operation(y, z, cd["mul"])
            x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
            if (rou+1) == round_inf[2]:
                w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(w)
                statement += subcells_operation(z, w, cd["mul"])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
            else:
                statement += subcells_operation(z, x1, cd["mul"])
            x = copy.deepcopy(x1)
            if rou < 7:
                tk1 = related_round_key_var_dec("tk", rou+1, cd["block_size"], cd["mul"])
                for m in range(0, cd["mul"]):
                    statement += tweakey_schedule(tk[m], tk1[m])
                tk = copy.deepcopy(tk1)

        elif rou == 7:
            all_var += copy.deepcopy(x)
            y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(y)
            x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
            statement += mixcolumns_operation(x, y, cd["mul"])
            if (rou+1) == round_inf[2]:
                w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(w)
                statement += subcells_operation(y, w, cd["mul"])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
            else:
                statement += subcells_operation(y, x1, cd["mul"])
            x = copy.deepcopy(x1)

        else:
            all_var += copy.deepcopy(tk)
            all_var += copy.deepcopy(x)
            y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(y)
            z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(z)

            statement += mixcolumns_operation(x, y, cd["mul"])
            for m in range(0, cd["mul"]):
                statement += inv_add_constants_and_tweakey_operation(y[m], z[m], round_constants[15-rou], tk[m], rk[m])
            x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
            if (rou+1) == round_inf[2]:
                w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(w)
                statement += subcells_operation(z, w, cd["mul"])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
            else:
                statement += subcells_operation(z, x1, cd["mul"])
            x = copy.deepcopy(x1)
            tk1 = related_round_key_var_dec("tk", rou + 1, cd["block_size"], cd["mul"])
            for m in range(0, cd["mul"]):
                statement += inv_tweakey_schedule(tk[m], tk1[m])
            tk = copy.deepcopy(tk1)
    all_var += copy.deepcopy(tk)
    all_var += copy.deepcopy(x)
    y = state_var_dec("y", round_inf[1], cd["block_size"], cd["mul"])
    all_var += copy.deepcopy(y)
    if round_inf[1] < 8:
        for m in range(0, cd["mul"]):
            statement += add_constants_and_tweakey_operation(x[m], y[m], round_constants[round_inf[1]-1], tk[m], rk[m])
        end_values = copy.deepcopy(y)
    else:
        z = state_var_dec("z", round_inf[1], cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)
        statement += mixcolumns_operation(x, y, cd["mul"])
        for m in range(0, cd["mul"]):
            statement += inv_add_constants_and_tweakey_operation(y[m], z[m], round_constants[15-round_inf[1]], tk[m], rk[m])
        end_values = copy.deepcopy(z)

    return begin_values, end_values, all_var, key_values, statement


def single_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()

    rk = single_key_var_dec("rk", cd["block_size"])
    all_var.append(copy.deepcopy(rk))
    tk = single_round_key_var_dec("tk", round_inf[0], cd["block_size"])

    x = state_var_dec("x", round_inf[0], cd["block_size"], cd["mul"])
    begin_values = copy.deepcopy(x)

    for rou in range(round_inf[0], round_inf[1]):

        if rou < 8:
            all_var.append(copy.deepcopy(tk))
            all_var += copy.deepcopy(x)
            y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(y)
            z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(z)

            for m in range(0, cd["mul"]):
                statement += add_constants_and_tweakey_operation(x[m], y[m], round_constants[rou], tk, rk)
            statement += mixcolumns_operation(y, z, cd["mul"])
            x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
            if (rou+1) == round_inf[2]:
                w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(w)
                statement += subcells_operation(z, w, cd["mul"])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
            else:
                statement += subcells_operation(z, x1, cd["mul"])
            x = copy.deepcopy(x1)
            tk1 = single_round_key_var_dec("tk", rou+1, cd["block_size"])
            statement += tweakey_schedule(tk, tk1)
            tk = copy.deepcopy(tk1)

        elif rou == 8:
            all_var += copy.deepcopy(x)
            y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(y)
            x1 = state_var_dec("x", rou + 1, cd["block_size"], cd["mul"])
            statement += mixcolumns_operation(x, y, cd["mul"])
            if (rou + 1) == round_inf[2]:
                w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(w)
                statement += subcells_operation(y, w, cd["mul"])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
            else:
                statement += subcells_operation(y, x1, cd["mul"])
            x = copy.deepcopy(x1)

        else:
            all_var.append(copy.deepcopy(tk))
            all_var += copy.deepcopy(x)
            y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(y)
            z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(z)

            tk1 = single_round_key_var_dec("tk", rou + 1, cd["block_size"])
            statement += inv_tweakey_schedule(tk, tk1)
            tk = copy.deepcopy(tk1)
            statement += mixcolumns_operation(x, y, cd["mul"])
            for m in range(0, cd["mul"]):
                statement += inv_add_constants_and_tweakey_operation(y[m], z[m], round_constants[16-rou], tk, rk)
            x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
            if (rou + 1) == round_inf[2]:
                w = state_var_dec("w", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(w)
                statement += subcells_operation(z, w, cd["mul"])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
            else:
                statement += subcells_operation(z, x1, cd["mul"])
            x = copy.deepcopy(x1)

    all_var += copy.deepcopy(tk)
    all_var += copy.deepcopy(x)
    y = state_var_dec("y", round_inf[1], cd["block_size"], cd["mul"])
    all_var += copy.deepcopy(y)
    if round_inf[1] < 9:
        for m in range(0, cd["mul"]):
            statement += add_constants_and_tweakey_operation(x[m], y[m], round_constants[round_inf[1]], tk[m], rk[m])
        end_values = copy.deepcopy(y)
    else:
        z = state_var_dec("z", round_inf[1], cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)
        statement += mixcolumns_operation(x, y, cd["mul"])
        for m in range(0, cd["mul"]):
            statement += inv_add_constants_and_tweakey_operation(y[m], z[m], round_constants[15-round_inf[1]+1], tk[m], rk[m])
        end_values = copy.deepcopy(z)

    return begin_values, end_values, all_var, statement


def __mb_mode1(cd, round_inf):
    statement = ""

    if cd["scenario"] == "RK":
        begin_values, end_values, all_var, key_values, statement1 = related_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var, cd["size"])
        for m in range(1, cd["mul"]):
            statement += xor_operate(begin_values[0], begin_values[m], cd["b{}".format(m)], cd["mode"][1])
        for m in range(1, cd["mul"]):
            statement += xor_operate(key_values[0][0], key_values[0][m], ["0bin0000" for ii in range(cd["block_size"])], cd["mode"][1])
        for m in range(1, cd["mul"]):
            statement += xor_operate(key_values[1][0], key_values[1][m], cd["k{}".format(m)], cd["mode"][1])

        statement += statement1

        for m in range(1, cd["mul"]):
            statement += xor_operate(end_values[0], end_values[m], cd["e{}".format(m)], cd["mode"][1])

    elif cd["scenario"] == "SK":
        begin_values, end_values, all_var, statement1 = single_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var, cd["size"])
        for m in range(1, cd["mul"]):
            statement += xor_operate(begin_values[0], begin_values[m], cd["b{}".format(m)], cd["mode"][1])

        statement += statement1

        for m in range(1, cd["mul"]):
            statement += xor_operate(end_values[0], end_values[m], cd["e{}".format(m)], cd["mode"][1])
    else:
        print("This scenario is invalid.")

    statement += trailer([], [])
    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __mb_mode1(cd, round_inf)
