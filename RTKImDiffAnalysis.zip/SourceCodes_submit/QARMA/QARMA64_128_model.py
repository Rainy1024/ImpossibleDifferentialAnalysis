#!/usr/bin/python
# -*- coding: UTF-8 -*-

import subprocess
import os
import copy

sbox = [[0x0, 0xe, 0x2, 0xa, 0x9, 0xf, 0x8, 0xb, 0x6, 0x4, 0x3, 0x7, 0xd, 0xc, 0x1, 0x5],\
         [0xa, 0xd, 0xe, 0x6, 0xf, 0x7, 0x3, 0x5, 0x9, 0x8, 0x0, 0xc, 0xb, 0x1, 0x2, 0x4],\
         [0xb, 0x6, 0x8, 0xf, 0xc, 0x0, 0x9, 0xe, 0x3, 0x7, 0x4, 0x5, 0xd, 0x2, 0x1, 0xa]]
permutation = [0, 11, 6, 13, 10, 1, 12, 7, 5, 14, 3, 8, 15, 4, 9, 2]
inv_permutation = [0, 5, 15, 10, 13, 8, 2, 7, 11, 14, 4, 1, 6, 3, 9, 12]
tweakey_perm = [6, 5, 14, 15, 0, 1, 2, 3, 7, 12, 13, 4, 8, 9, 10, 11]
inv_tweakey_perm = [4, 5, 6, 7, 11, 1, 0, 8, 12, 13, 14, 15, 9, 10, 2, 3]
matrix = [[0, 1, 2, 1], [1, 0, 1, 2], [2, 1, 0, 1], [1, 2, 1, 0]]
alpha = [0xc, 0x0, 0xa, 0xc, 0x2, 0x9, 0xb, 0x7, 0xc, 0x9, 0x7, 0xc, 0x5, 0x0, 0xd, 0xd]
round_constant = [[0x1, 0x3, 0x1, 0x9, 0x8, 0xa, 0x2, 0xe, 0x0, 0x3, 0x7, 0x0, 0x7, 0x3, 0x4, 0x4],\
                  [0xa, 0x4, 0x0, 0x9, 0x3, 0x8, 0x2, 0x2, 0x2, 0x9, 0x9, 0xf, 0x3, 0x1, 0xd, 0x0],\
                  [0x0, 0x8, 0x2, 0xe, 0xf, 0xa, 0x9, 0x8, 0xe, 0xc, 0x4, 0xe, 0x6, 0xc, 0x8, 0x9],\
                  [0x4, 0x5, 0x2, 0x8, 0x2, 0x1, 0xe, 0x6, 0x3, 0x8, 0xd, 0x0, 0x1, 0x3, 0x7, 0x7],\
                  [0xb, 0xe, 0x5, 0x4, 0x6, 0x6, 0xc, 0xf, 0x3, 0x4, 0xe, 0x9, 0x0, 0xc, 0x6, 0xc],\
                  [0x3, 0xf, 0x8, 0x4, 0xd, 0x5, 0xb, 0x5, 0xb, 0x5, 0x4, 0x7, 0x0, 0x9, 0x1, 0x7]]

inv_round_constant = copy.deepcopy(round_constant[::-1])


def header(var1, size):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR({});\n".format(size)
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, round_index, var_size, mul):
    var0 = [["p{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_key_var_dec(var, var_size, mul):
    var0 = [["k{}_{}_{}".format(j, var, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_round_key_var_dec(var, round_index, var_size, mul):
    var0 = [["k{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def single_key_var_dec(var, var_size):
    var0 = ["k_{}_{}".format(var, j) for j in range(0, var_size)]
    return var0


def single_round_key_var_dec(var, round_index, var_size):
    var0 = ["k_{}_{}_{}".format(var, round_index, j) for j in range(0, var_size)]
    return var0


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver_prove(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return False, res
    else:
        return True, res


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def __xor_operate_branch(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        if var_out[var_index] == "0bin0000":
            xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
        else:
            xor_statement += "ASSERT((BVXOR({0}, {1}))[3:3]|(BVXOR({0}, {1}))[2:2]|(BVXOR({0}, {1}))[1:1]|(BVXOR({0}, {1}))[0:0] = 0bin1);\n".format(var_in1[var_index], var_in2[var_index])
    return xor_statement


def __xor_operate_detail(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
    return xor_statement


def xor_operate(var1, var2, values, mode):
    if mode == "branch":
        return __xor_operate_branch(var1, var2, values)
    elif mode == "detail":
        return __xor_operate_detail(var1, var2, values)
    else:
        print("Input format error!")


def xor_operate_two(var_in1, var_in2, var_out):
    statement = ""
    for index in range(len(var_in1)):
        statement += "ASSERT({} = BVXOR({}, {}));\n".format(
            var_out[index], var_in1[index], var_in2[index]
        )
    return statement


def xor_operate_three(var_in1, var_in2, var_in3, var_out):
    statement = ""
    for index in range(len(var_in1)):
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(
            var_out[index], var_in1[index], var_in2[index], var_in3[index]
        )
    return statement


def perm_wire(var1, perm):
    var = ["" for i in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[i] = var1[perm[i]]
    return var


def perm_wire_out(var1, perm):
    var = ["" for i in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[perm[i]] = var1[i]
    return var


def white_key_operation(var_in, var_out):
    statement = ""
    for i in range(len(var_in)-1):
        statement += "ASSERT({0} = {1}[0:0]@{2}[3:3]@{2}[2:2]@{2}[1:1]);\n".format(var_out[i], var_in[(i+15) % 16], var_in[i])
    statement += "ASSERT({0} = {1}[0:0]@{2}[3:3]@{2}[2:2]@BVXOR({2}[1:1], {3}[3:3]));\n".format(var_out[15], var_in[14], var_in[15], var_in[0])
    return statement


def tweakey_schedule(var_in, var_out):
    statement = ""
    LFSR_position = [0, 1, 3, 4, 8, 11, 13]
    tweakey_perm = [6, 5, 14, 15, 0, 1, 2, 3, 7, 12, 13, 4, 8, 9, 10, 11]
    var = copy.deepcopy(perm_wire(var_in, tweakey_perm))
    for i in range(len(var_in)):
        if i in LFSR_position:
            statement += "ASSERT({0} = BVXOR({1}[0:0], {1}[1:1])@{1}[3:3]@{1}[2:2]@{1}[1:1]);\n".format(var_out[i], var[i])
        else:
            statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def inv_tweakey_schedule(var_in, var_out):
    statement = ""
    LFSR_position = [0, 1, 3, 4, 8, 11, 13]
    inv_tweakey_perm = [4, 5, 6, 7, 11, 1, 0, 8, 12, 13, 14, 15, 9, 10, 2, 3]
    var = copy.deepcopy(perm_wire(var_in, inv_tweakey_perm))
    for i in range(len(var_in)):
        if i in LFSR_position:
            statement += "ASSERT({0} = {1}[2:2]@{1}[1:1]@{1}[0:0]@(BVXOR({1}[0:0], {1}[3:3])));\n".format(
                var_out[i], var[i]
            )
        else:
            statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def init_addroundkeys_operation(var_in, var_out, w0, k0, tk0):
    statement = ""
    for i in range(len(var_in)):
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, BVXOR({}, 0bin{:0<4b})))));\n".format(
            var_out[i], var_in[i], w0[i], k0[i], tk0[i], round_constant[0][i]
        )
    return statement


def end_addroundkeys_func(var_in, var_out, w1, k0, tk0):
    statement = ""
    for i in range(len(var_in)):
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, BVXOR({}, BVXOR(0bin{:0<4b}, 0bin{:0<4b}))))));\n".format(
            var_out[i], var_in[i], w1[i], k0[i], tk0[i], round_constant[0][i], alpha[i]
        )
    return statement


def addroundkeys_operation(var_in, var_out, k0, rc, tk):
    statement = ""
    var = copy.deepcopy(perm_wire(var_out, permutation))
    for i in range(len(var_in)):
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, 0bin{:0>4b}))));\n".format(
            var[i], var_in[i], tk[i], k0[i], rc[i]
        )
    return statement


def inv_addroundkeys_operation(var_in, var_out, k0, rc, tk):
    statement = ""
    var = copy.deepcopy(perm_wire(var_in, inv_permutation))
    for i in range(len(var_in)):
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, BVXOR(0bin{:0>4b}, 0bin{:0>4b})))));\n".format(
            var_out[i], var[i], tk[i], k0[i], rc[i], alpha[i]
        )
    return statement


def __sbox_operation(var_in, var_out, sbox):
    statement1 = "0bin"
    for ii in range(0, 4):
        statement1 += "{}".format((sbox[0] >> (3-ii)) & 0x1)
    for i in range(1, 16):
        iv = "0bin"
        for j in range(0, 4):
            iv += "{}".format((i >> (3-j)) & 0x1)
        siv = "0bin"
        for j in range(0, 4):
            siv += "{}".format((sbox[i] >> (3-j)) & 0x1)
        statement1 = "(IF {} = {} THEN {} ELSE {} ENDIF)".format(var_in, iv, siv, statement1)
    statement = "ASSERT({} = {});\n".format(var_out, statement1)
    return statement


def subcells_operation(var_in, var_out, sbox):
    statement = ""
    for i in range(0, len(var_in)):
        statement += __sbox_operation(var_in[i], var_out[i], sbox)
    return statement


def mixcolumns_operation(var_in, var_out):
    statement = ""
    for i in range(0, len(var_in)):
        if i < 4:
            statement += "ASSERT({0} = BVXOR({1}[2:2]@{1}[1:1]@{1}[0:0]@{1}[3:3], BVXOR({2}[1:1]@{2}[0:0]@{2}[3:3]@{2}[2:2], {3}[2:2]@{3}[1:1]@{3}[0:0]@{3}[3:3])));\n".format(
                var_out[i], var_in[i+4], var_in[i+8], var_in[i+12]
            )
        elif i < 8:
            statement += "ASSERT({0} = BVXOR({1}[2:2]@{1}[1:1]@{1}[0:0]@{1}[3:3], BVXOR({2}[2:2]@{2}[1:1]@{2}[0:0]@{2}[3:3], {3}[1:1]@{3}[0:0]@{3}[3:3]@{3}[2:2])));\n".format(
                var_out[i], var_in[i-4], var_in[i+4], var_in[i+8]
            )
        elif i < 12:
            statement += "ASSERT({0} = BVXOR({1}[1:1]@{1}[0:0]@{1}[3:3]@{1}[2:2], BVXOR({2}[2:2]@{2}[1:1]@{2}[0:0]@{2}[3:3], {3}[2:2]@{3}[1:1]@{3}[0:0]@{3}[3:3])));\n".format(
                var_out[i], var_in[i-8], var_in[i-4], var_in[i+4]
            )
        else:
            statement += "ASSERT({0} = BVXOR({1}[2:2]@{1}[1:1]@{1}[0:0]@{1}[3:3], BVXOR({2}[1:1]@{2}[0:0]@{2}[3:3]@{2}[2:2], {3}[2:2]@{3}[1:1]@{3}[0:0]@{3}[3:3])));\n".format(
                var_out[i], var_in[i-12], var_in[i-8], var_in[i-4]
            )

    return statement


def __middle_mixcolumn_operation(var_in, var_out, k1):
    statement = ""
    var1 = ["" for i1 in range(len(var_in))]
    var2 = ["" for i2 in range(len(var_out))]
    var1[:] = perm_wire(var_in, permutation)
    var2[:] = perm_wire_out(var_out, inv_permutation)
    for i in range(0, len(var_in)):
        if i < 4:
            statement += "ASSERT({0} = BVXOR({4}, BVXOR({1}[2:2]@{1}[1:1]@{1}[0:0]@{1}[3:3], BVXOR({2}[1:1]@{2}[0:0]@{2}[3:3]@{2}[2:2], {3}[2:2]@{3}[1:1]@{3}[0:0]@{3}[3:3]))));\n".format(
                var2[i], var1[i+4], var1[i+8], var1[i+12], k1[i]
            )
        elif i < 8:
            statement += "ASSERT({0} = BVXOR({4}, BVXOR({1}[2:2]@{1}[1:1]@{1}[0:0]@{1}[3:3], BVXOR({2}[2:2]@{2}[1:1]@{2}[0:0]@{2}[3:3], {3}[1:1]@{3}[0:0]@{3}[3:3]@{3}[2:2]))));\n".format(
                var2[i], var1[i-4], var1[i+4], var1[i+8], k1[i]
            )
        elif i < 12:
            statement += "ASSERT({0} = BVXOR({4}, BVXOR({1}[1:1]@{1}[0:0]@{1}[3:3]@{1}[2:2], BVXOR({2}[2:2]@{2}[1:1]@{2}[0:0]@{2}[3:3], {3}[2:2]@{3}[1:1]@{3}[0:0]@{3}[3:3]))));\n".format(
                var2[i], var1[i-8], var1[i-4], var1[i+4], k1[i]
            )
        else:
            statement += "ASSERT({0} = BVXOR({4}, BVXOR({1}[2:2]@{1}[1:1]@{1}[0:0]@{1}[3:3], BVXOR({2}[2:2]@{2}[1:1]@{2}[0:0]@{2}[3:3], {3}[2:2]@{3}[1:1]@{3}[0:0]@{3}[3:3]))));\n".format(
                var2[i], var1[i-12], var1[i-8], var1[i-4], k1[i]
            )
    return statement


def __constraint_func(var_in, var_out, positions, mul):
    statement = ""
    for m in range(1, mul):
        for i in range(len(var_in[0])):
            if i in positions:
                statement += "ASSERT(BVXOR({}, BVXOR({}, BVXOR({}, {}))) = 0bin0000);\n".format(
                    var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i]
                )
    return statement


def __constraint_func_or(var_in, var_out, values, mul):
    statement = ""
    for m in range(1, mul):
        tmp = "ASSERT(0bin0000"
        for i in range(len(var_in[0])):
            if i in values:
                tmp += "|(BVXOR({}, BVXOR({}, BVXOR({}, {}))))".format(var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i])
        tmp += " = 0bin0000);\n"
        statement += tmp
    return statement


def related_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    key_values = list()
    w0 = related_key_var_dec("w0", cd["block_size"], cd["mul"])
    w1 = related_key_var_dec("w1", cd["block_size"], cd["mul"])
    rk = related_key_var_dec("rk", cd["block_size"], cd["mul"])
    tk = related_round_key_var_dec("tk", round_inf[0], cd["block_size"], cd["mul"])
    x = state_var_dec("x", round_inf[0], cd["block_size"], cd["mul"])

    key_values.append(copy.deepcopy(w0))
    key_values.append(copy.deepcopy(rk))
    key_values.append(copy.deepcopy(tk))
    begin_values = copy.deepcopy(x)

    all_var += copy.deepcopy(w0)
    all_var += copy.deepcopy(w1)
    all_var += copy.deepcopy(rk)

    for m in range(0, cd["mul"]):
        statement += white_key_operation(w0[m], w1[m])
    for rou in range(round_inf[0], round_inf[1]):
        all_var += copy.deepcopy(x)
        y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(y)
        z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        if rou < 6:
            all_var += copy.deepcopy(tk)
            for m in range(0, cd["mul"]):
                statement += addroundkeys_operation(x[m], y[m], rk[m], round_constant[rou], tk[m])
                statement += mixcolumns_operation(y[m], z[m])
            x1 = state_var_dec("x", rou + 1, cd["block_size"], cd["mul"])
            if (rou+1) == round_inf[2]:
                xt = state_var_dec("xt", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(xt)
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(z[m], xt[m], sbox[0])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(xt, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(xt, x1, cd["positions"], cd["mul"])
            else:
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(z[m], x1[m], sbox[0])
            x = copy.deepcopy(x1)

            tk1 = related_round_key_var_dec("tk", rou+1, cd["block_size"], cd["mul"])
            for m in range(0, cd["mul"]):
                statement += tweakey_schedule(tk[m], tk1[m])
            tk = copy.deepcopy(tk1)

        elif rou == 6:
            all_var += copy.deepcopy(tk)
            for m in range(cd["mul"]):
                var1 = copy.deepcopy(perm_wire_out(y[m], permutation))
                statement += xor_operate_three(x[m], tk[m], w1[m], var1)
                statement += mixcolumns_operation(y[m], z[m])
            x1 = state_var_dec("x", rou + 1, cd["block_size"], cd["mul"])
            if (rou+1) == round_inf[2]:
                xt = state_var_dec("xt", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(xt)
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(z[m], xt[m], sbox[0])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(xt, x1, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(xt, x1, cd["positions"], cd["mul"])
            else:
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(z[m], x1[m], sbox[0])
            all_var += copy.deepcopy(x1)

            w = state_var_dec("w", rou+1, cd["block_size"], cd["mul"])
            for m in range(0, cd["mul"]):
                statement += __middle_mixcolumn_operation(x1[m], w[m], rk[m])
            x = copy.deepcopy(w)

        elif rou == 7:
            if (rou+1) == round_inf[2]:
                xt = state_var_dec("xt", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(xt)
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(x[m], xt[m], sbox[0])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(xt, y, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(xt, y, cd["positions"], cd["mul"])
            else:
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(x[m], y[m], sbox[0])
            x1 = state_var_dec("x", rou + 1, cd["block_size"], cd["mul"])
            for m in range(0, cd["mul"]):
                statement += mixcolumns_operation(y[m], z[m])
                var2 = copy.deepcopy(perm_wire(z[m], inv_permutation))
                statement += xor_operate_three(var2, tk[m], w0[m], x1[m])
            x = copy.deepcopy(x1)

        else:
            if round_inf[0] == 7:
                all_var += copy.deepcopy(tk)
            tk1 = related_round_key_var_dec("tk", rou, cd["block_size"], cd["mul"])
            for m in range(0, cd["mul"]):
                statement += inv_tweakey_schedule(tk[m], tk1[m])
            tk = copy.deepcopy(tk1)
            all_var += copy.deepcopy(tk)

            if (rou+1) == round_inf[2]:
                xt = state_var_dec("xt", rou, cd["block_size"], cd["mul"])
                all_var += copy.deepcopy(xt)
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(x[m], xt[m], sbox[0])
                if cd["flag"] == "contraction":
                    statement += __constraint_func(xt, y, cd["positions"], cd["mul"])
                else:
                    statement += __constraint_func_or(xt, y, cd["positions"], cd["mul"])
            else:
                for m in range(0, cd["mul"]):
                    statement += subcells_operation(x[m], y[m], sbox[0])
            x1 = state_var_dec("x", rou + 1, cd["block_size"], cd["mul"])
            for m in range(0, cd["mul"]):
                statement += mixcolumns_operation(y[m], z[m])
                statement += inv_addroundkeys_operation(z[m], x1[m], rk[m], inv_round_constant[rou-8], tk[m])
            x = copy.deepcopy(x1)

    if round_inf[1] < 7:
        all_var += copy.deepcopy(tk)
        all_var += copy.deepcopy(x)
    else:
        all_var += copy.deepcopy(x)
    end_values = copy.deepcopy(x)
    return begin_values, end_values, key_values, all_var, statement


def __mb_mode1(cd, round_inf):
    statement = ""

    if cd["scenario"] == "RK":
        begin_values, end_values, key_values, all_var, statement1 = related_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var, cd["size"])
        for m in range(1, cd["mul"]):
            statement += xor_operate(begin_values[0], begin_values[m], cd["b{}".format(m)], cd["mode"][1])
        for m in range(1, cd["mul"]):
            statement += xor_operate(key_values[0][0], key_values[0][m], ["0bin0000" for i1 in range(cd["block_size"])], cd["mode"][1])
        for m in range(1, cd["mul"]):
            statement += xor_operate(key_values[1][0], key_values[1][m], ["0bin0000" for i2 in range(cd["block_size"])], cd["mode"][1])
        for m in range(1, cd["mul"]):
            statement += xor_operate(key_values[2][0], key_values[2][m], cd["k{}".format(m)], cd["mode"][1])

        statement += statement1

        for m in range(1, cd["mul"]):
            statement += xor_operate(end_values[0], end_values[m], cd["e{}".format(m)], cd["mode"][1])

    else:
        print("This scenario is invalid.")

    statement += trailer([], [])
    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __mb_mode1(cd, round_inf)
