#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
search impossible differential
"""

import copy
import QARMA64_128_model
import time
import math
import os

if __name__ == "__main__":

    parameters = dict()

    parameters["mul"] = 2
    parameters["cipher_name"] = "QARMA64_128"
    parameters["cipher_size"] = 64
    parameters["key_size"] = 128
    parameters["sbox_size"] = 4
    parameters["sbox_num"] = 16
    parameters["block_size"] = 16
    parameters["size"] = 4
    parameters["scenario"] = "RK"
    parameters["mode"] = ["ID", "detail"]

    parameters["flag"] = "contraction"
    folder1 = parameters["cipher_name"] + "_{}_{}_{}".format(parameters["flag"], parameters["mode"][0], parameters["scenario"])
    if not os.path.exists(folder1):
        os.mkdir(folder1)

    position_space = list()
    for i in range(parameters["sbox_num"]):
        position_space.append(copy.deepcopy([i]))

    search_space = list()
    for i1 in range(0, 16):
        b1 = ["0bin0000" for b1_i in range(0, 16)]
        for i2 in range(1, 16):
            iv = "0bin"
            for i3 in range(0, 4):
                iv += "{}".format((i2 >> (3 - i3)) & 0x1)
            b1[i1] = iv
            e1 = ["0bin0000" for e1_j in range(0, 16)]
            search_space.append(copy.deepcopy([b1, e1]))

    folder = folder1 + "////" + parameters["cipher_name"] + "_{}_{}_{}way_contraction".format(parameters["scenario"], parameters["mode"][0], parameters["mul"])
    if not os.path.exists(folder):
        os.mkdir(folder)

    parameters["record_file"] = folder + "////" + parameters["cipher_name"] + "_record_{}_{}.txt".format(parameters["scenario"], parameters["mode"][0])
    parameters["search_log"] = folder + "////" + parameters["cipher_name"] + "_search_{}_{}.txt".format(parameters["scenario"], parameters["mode"][0])
    total_search = len(search_space)
    distinguish_find = True
    begin_round = 6
    distinguish_rounds = 5
    while distinguish_find:
        distinguish_find = False
        end_round = begin_round + distinguish_rounds
        round_i = list()
        a = math.ceil((begin_round + 1 + end_round) / 2)
        if ((begin_round + 1 + end_round) % 2) == 0:
            round_i.append(copy.deepcopy(a))
            round_i.append(copy.deepcopy(a - 1))
            round_i.append(copy.deepcopy(a + 1))
        else:
            round_i.append(copy.deepcopy(a))
            round_i.append(copy.deepcopy(a - 1))
        search_count = 0
        t1 = time.time()
        while search_count < len(search_space):
            parameters["k1"] = copy.deepcopy(search_space[search_count][0])
            parameters["b1"] = copy.deepcopy(search_space[search_count][1])
            parameters["e1"] = copy.deepcopy(search_space[search_count][1])
            rf = open(parameters["record_file"], "a")
            rf.write("*" * 20)
            rf.write("when the values:\n")
            rf.write("b1 = {}\n".format(str(parameters["b1"])))
            rf.write("e1 = {}\n".format(str(parameters["e1"])))
            rf.write("k1 = {}\n".format(str(parameters["k1"])))
            rf.close()
            for index in range(0, len(round_i)):
                parameters["solve_file"] = folder + "////" + parameters["cipher_name"] + "_round{}_{}_{}.stp".format(begin_round, end_round, round_i[index])
                for p in range(0, 16):
                    parameters["positions"] = copy.deepcopy([p])
                    round_inf = [begin_round, end_round, round_i[index]]
                    t11 = time.time()
                    QARMA64_128_model.model_build(parameters, round_inf)
                    flag = QARMA64_128_model.solver(parameters["solve_file"])
                    t22 = time.time()
                    print(t22 - t11)
                    if flag:
                        rf = open(parameters["record_file"], "a")
                        rf.write("*" * 20)
                        rf.write("{} round impossible distinguish was found.\n".format(distinguish_rounds))
                        rf.write("with the contraction in round {} position {}.\n".format(round_i[index],parameters["positions"]))
                        rf.close()
                    else:
                        print("testing: round = {}_{}, search_count = {}, total_search = {}".format(begin_round, end_round, search_count, total_search))
                        print("round_i = {}, position = {}\n".format(round_i[index], parameters["positions"]))
                        sf = open(parameters["search_log"], "a")
                        sf.write("*" * 20)
                        sf.write("testing:\ntime = {}, round = {}_{}, search_count = {}, total_search = {}\n".format(t22 - t11, begin_round, end_round, search_count, total_search))
                        sf.write("contraction round = {}, position = {}\n\n".format(round_i[index], parameters["positions"]))
                        sf.close()
            search_count += 1
