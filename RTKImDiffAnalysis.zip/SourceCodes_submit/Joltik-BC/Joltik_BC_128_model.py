#!/usr/bin/python
# -*- coding: UTF-8 -*-

import subprocess
import os
import copy

sbox = [0xe, 0x4, 0xb, 0x2, 0x3, 0x8, 0x0, 0x9, 0x1, 0xa, 0x7, 0xf, 0x6, 0xc, 0x5, 0xd]
tweakey_permutation = [1, 6, 11, 12, 5, 10, 15, 0, 9, 14, 3, 4, 13, 2, 7, 8]
permutation = [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]
MC = [[1, 4, 9, 13], [4, 1, 13, 9], [9, 13, 1, 4], [13, 9, 4, 1]]
RC = [0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3e, 0x3d, 0x3B, 0x37, 0x2F, 0x1E, 0x3C,\
      0x39, 0x33, 0x27, 0x0e, 0x1d, 0x3a, 0x35, 0x2b, 0x16, 0x2c, 0x18, 0x30,\
      0x21, 0x02, 0x05, 0x0b, 0x17, 0x2e, 0x1c, 0x38, 0x31]

alpha = [[0, 1, 0, 0],\
         [0, 0, 1, 0],\
         [1, 0, 0, 1],\
         [1, 0, 0, 0]]

matrix = [[1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1],\
          [0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1],\
          [0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0],\
          [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1],\
          [0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1],\
          [1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1],\
          [1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0],\
          [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 1],\
          [0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0],\
          [1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1],\
          [0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0],\
          [0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0],\
          [0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0],\
          [0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0],\
          [1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0],\
          [0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1]]
m1 = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]
m4 = [[0, 0, 1, 0], [1, 0, 0, 1], [1, 1, 0, 0], [0, 1, 0, 0]]
m9 = [[0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 1]]
m13 = [[0, 0, 1, 1], [0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 1, 1]]


def header(var1):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR(1);\n"
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, round_index, var_size, mul):
    var0 = [["p{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_round_key_var_dec(var, round_index, var_size, mul):
    var0 = [["k{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def single_round_key_var_dec(var, round_index, var_size):
    var0 = ["k_{}_{}_{}".format(var, round_index, i) for i in range(0, var_size)]
    return var0


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver1(solve_file):
    stp_parameters = ["stp", "--cryptominisat", "--thread", "6", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def res_solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True, res
    else:
        return False, res


def var_value_assign(var, values):
    statement = ""
    for i in range(0, len(var)):
        statement += "ASSERT({} = 0bin{});\n".format(var[i], values[i])
    return statement


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def __xor_operate_branch(var1, var2, var3):
    xor_statement = ""
    tmp = ""
    for var_index in range(0, len(var1)):
        if var3[var_index] == "0bin0":
            xor_statement += __xor_operate_1(var1[var_index], var2[var_index], var3[var_index])
        else:
            tmp += "|(BVXOR({0},{1}))".format(var1[var_index], var2[var_index])
    if tmp != "":
        xor_statement += ("ASSERT(0bin0" + tmp + " = 0bin1);\n")
    return xor_statement


def __xor_operate_detail(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
    return xor_statement


def xor_operate(var1, var2, values, mode):
    if mode == "branch":
        return __xor_operate_branch(var1, var2, values)
    elif mode == "detail":
        return __xor_operate_detail(var1, var2, values)
    else:
        print("Input format error!")


def perm_wire_in(var1, perm):
    var = ["" for ii in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[perm[i]] = var1[i]
    return var


def perm_wire_out(var1, perm):
    var = ["" for ii in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[i] = var1[perm[i]]
    return var


def generate_round_constants_wise(round_inf):
    rc = list()
    for rou in range(round_inf[0], round_inf[1]):
        sub_rc = ["0bin0000", "0bin0001", "0bin0010", "0bin0011", "0bin0", "0bin0", "0bin0", "0bin0",\
                  "0bin0000", "0bin0000", "0bin0000", "0bin0000", "0bin0000", "0bin0000", "0bin0000", "0bin0000"]
        temp = []
        for j in range(6):
            temp += "{}".format((RC[rou] >> j) & 0x1)
        sub_rc[4] += (temp[5] + temp[4] + temp[3])
        sub_rc[5] += (temp[2] + temp[1] + temp[0])
        sub_rc[6] += (temp[5] + temp[4] + temp[3])
        sub_rc[7] += (temp[2] + temp[1] + temp[0])
        rc.append(copy.deepcopy(sub_rc))
    return rc


def generate_round_constants_bit(round_inf):
    rc = list()
    fiv = list()
    for s in range(0, 4):
        for j in range(0, 4):
            iv = "0bin"
            iv += "{}".format((s >> (3-j)) & 0x1)
            fiv.append(iv)
    biv = ["0bin0" for i in range(32)]
    for rou in range(round_inf[0], round_inf[1]+1):
        sub_rc = []
        temp = []
        for j in range(6):
            temp.append("0bin{}".format((RC[rou] >> j) & 0x1))
        sub_rc.append("0bin0")
        sub_rc += temp[5:2:-1]
        sub_rc.append("0bin0")
        sub_rc += temp[0:3][::-1]
        miv = sub_rc + sub_rc
        rc.append(copy.deepcopy(fiv+miv+biv))
    return rc


def __xtimes_matrix_func(var_in, var_out, matrix):
    statement1 = ""
    for i in range(len(matrix)):
        statement1 += "ASSERT({} = ".format(var_out[i])
        total_num = matrix[i].count(1)
        num = 0
        for j in range(len(matrix[i])):
            if matrix[i][j] == 1:
                if num == total_num-1:
                    statement1 += "{}{};\n".format(var_in[j], ")" * total_num)
                else:
                    statement1 += "BVXOR({}, ".format(var_in[j])
                    num += 1
    return statement1


def tweakey1_bit_schedule(var_in, var_out):
    statement = ""
    tp = [0 for i in range(4*len(tweakey_permutation))]
    for i in range(len(tweakey_permutation)):
        for j in range(0, 4):
            tp[4*i+j] = tweakey_permutation[i]*4+j

    var = copy.deepcopy(perm_wire_in(var_in, tp))
    for i in range(len(var_in)):
        statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def tweakey2_bit_schedule(var_in, var_out):
    statement = ""
    tp = [0 for i in range(4 * len(tweakey_permutation))]
    for i in range(len(tweakey_permutation)):
        for j in range(0, 4):
            tp[4*i+j] = tweakey_permutation[i]*4+j

    var = copy.deepcopy(perm_wire_out(var_out, tp))
    for i in range(16):
        begin_index = 4*i
        end_index = 4*i+4
        statement += __xtimes_matrix_func(var_in[begin_index:end_index], var[begin_index:end_index], alpha)
    return statement


def addroundtweakey_operation(var_in, var_out, tk1, tk2, round_constants):
    statement = ""
    for i in range(len(var_in)):
        statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, {}))));\n".format(
            var_out[i], round_constants[i], tk2[i], tk1[i], var_in[i]
        )
    return statement


def __sbox_operation(v1, v2):
    var1 = "{}@{}@{}@{}".format(v1[0], v1[1], v1[2], v1[3])
    var2 = "{}@{}@{}@{}".format(v2[0], v2[1], v2[2], v2[3])
    statement1 = "0bin1110"
    for i in range(1, 16):
        iv = "0bin"
        for j in range(0, 4):
            iv += "{}".format((i >> (3 - j)) & 0x1)
        siv = "0bin"
        for j in range(0, 4):
            siv += "{}".format((sbox[i] >> (3 - j)) & 0x1)
        statement1 = "(IF {} = {} THEN {} ELSE {} ENDIF)".format(var1, iv, siv, statement1)
    statement = "ASSERT({} = {});\n".format(var2, statement1)
    return statement


def subcells_operation(var_in, var_out, mul):
    perm = [0 for i in range(4 * len(permutation))]
    for i in range(len(permutation)):
        for j in range(0, 4):
            perm[4*i+j] = permutation[i]*4+j
    s_box_size = 4
    s_box_statement = ""

    for m in range(mul):
        var = copy.deepcopy(perm_wire_out(var_in[m], perm))
        for s_box_index in range(0, 16):
            begin_index = s_box_index * s_box_size
            end_index = begin_index + s_box_size
            s_box_statement += __sbox_operation(var[begin_index:end_index], var_out[m][begin_index:end_index])
    return s_box_statement


def mixcolumns_func(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(4):
            begin_index = 16 * i
            end_index = 16 * i + 16
            statement += __xtimes_matrix_func(var_in[m][begin_index:end_index], var_out[m][begin_index:end_index], matrix)
    return statement


def __constraint_func(var_in, var_out, positions, mul):
    statement = ""
    for m in range(1, mul):
        for i in range(len(var_in[0])):
            if i in positions:
                statement += "ASSERT(BVXOR({}, BVXOR({}, BVXOR({}, {}))) = 0bin0);\n".format(
                    var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i]
                )
    return statement


def __constraint_func_or(var_in, var_out, values, mul):
    statement = ""
    for m in range(1, mul):
        tmp = "ASSERT(0bin0"
        for i in range(len(var_in[0])):
            if i in values:
                tmp += "|(BVXOR({}, BVXOR({}, BVXOR({}, {}))))".format(var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i])
        tmp += " = 0bin0);\n"
        statement += tmp
    return statement


def related_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    key_values = list()
    round_constants = generate_round_constants_bit(round_inf)
    tk1 = related_round_key_var_dec("tk1", round_inf[0], cd["cipher_size"], cd["mul"])
    tk2 = related_round_key_var_dec("tk2", round_inf[0], cd["cipher_size"], cd["mul"])
    x = state_var_dec("x", round_inf[0], cd["cipher_size"], cd["mul"])
    begin_values = copy.deepcopy(x)
    key_values.append(copy.deepcopy(tk1))
    key_values.append(copy.deepcopy(tk2))

    for rou in range(round_inf[0], round_inf[1]):
        all_var += copy.deepcopy(tk1)
        all_var += copy.deepcopy(tk2)
        all_var += copy.deepcopy(x)
        y = state_var_dec("y", rou, cd["cipher_size"], cd["mul"])
        all_var += copy.deepcopy(y)
        z = state_var_dec("z", rou, cd["cipher_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        for m in range(0, cd["mul"]):
            statement += addroundtweakey_operation(x[m], y[m], tk1[m], tk2[m], round_constants[0])
        if (rou+1) == round_inf[2]:
            w = state_var_dec("w", rou, cd["cipher_size"], cd["mul"])
            all_var += copy.deepcopy(w)
            statement += subcells_operation(y, w, cd["mul"])
            if cd["flag"] == "contraction":
                statement += __constraint_func(w, z, cd["positions"], cd["mul"])
            else:
                statement += __constraint_func_or(w, z, cd["positions"], cd["mul"])
        else:
            statement += subcells_operation(y, z, cd["mul"])

        x1 = state_var_dec("x", rou+1, cd["cipher_size"], cd["mul"])
        statement += mixcolumns_func(z, x1, cd["mul"])
        x = copy.deepcopy(x1)

        tk11 = related_round_key_var_dec("tk1", rou+1, cd["cipher_size"], cd["mul"])
        tk22 = related_round_key_var_dec("tk2", rou+1, cd["cipher_size"], cd["mul"])
        for m in range(0, cd["mul"]):
            statement += tweakey1_bit_schedule(tk1[m], tk11[m])
            statement += tweakey2_bit_schedule(tk2[m], tk22[m])
        tk1 = copy.deepcopy(tk11)
        tk2 = copy.deepcopy(tk22)

    y = state_var_dec("y", round_inf[1], cd["cipher_size"], cd["mul"])
    for m in range(0, cd["mul"]):
        statement += addroundtweakey_operation(x[m], y[m], tk1[m], tk2[m], round_constants[round_inf[1]])
    all_var += copy.deepcopy(tk1)
    all_var += copy.deepcopy(tk2)
    all_var += copy.deepcopy(x)
    all_var += copy.deepcopy(y)
    end_values = copy.deepcopy(y)

    return begin_values, end_values, all_var, key_values, statement


def single_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    round_constants = generate_round_constants_bit(round_inf)
    tk1 = single_round_key_var_dec("tk1", round_inf[0], cd["cipher_size"])
    tk2 = single_round_key_var_dec("tk2", round_inf[0], cd["cipher_size"])
    x = state_var_dec("x", round_inf[0], cd["cipher_size"], cd["mul"])
    begin_values = copy.deepcopy(x)

    for rou in range(round_inf[0], round_inf[1]):
        all_var.append(copy.deepcopy(tk1))
        all_var.append(copy.deepcopy(tk2))
        all_var += copy.deepcopy(x)
        y = state_var_dec("y", rou, cd["cipher_size"], cd["mul"])
        all_var += copy.deepcopy(y)
        z = state_var_dec("z", rou, cd["cipher_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        for m in range(0, cd["mul"]):
            statement += addroundtweakey_operation(x[m], y[m], tk1, tk2, round_constants[0])
        if (rou + 1) == round_inf[2]:
            w = state_var_dec("w", rou, cd["cipher_size"], cd["mul"])
            all_var += copy.deepcopy(w)
            statement += subcells_operation(y, w, cd["mul"])
            if cd["flag"] == "contraction":
                statement += __constraint_func(w, z, cd["positions"], cd["mul"])
            else:
                statement += __constraint_func_or(w, z, cd["positions"], cd["mul"])
        else:
            statement += subcells_operation(y, z, cd["mul"])

        x1 = state_var_dec("x", rou+1, cd["cipher_size"], cd["mul"])
        statement += mixcolumns_func(z, x1, cd["mul"])
        x = copy.deepcopy(x1)

        tk11 = single_round_key_var_dec("tk1", rou+1, cd["cipher_size"])
        tk22 = single_round_key_var_dec("tk2", rou+1, cd["cipher_size"])
        statement += tweakey1_bit_schedule(tk1, tk11)
        statement += tweakey2_bit_schedule(tk2, tk22)
        tk1 = copy.deepcopy(tk11)
        tk2 = copy.deepcopy(tk22)

    y = state_var_dec("y", round_inf[1], cd["cipher_size"], cd["mul"])
    for m in range(0, cd["mul"]):
        statement += addroundtweakey_operation(x[m], y[m], tk1, tk2, round_constants[round_inf[1]])
    all_var.append(copy.deepcopy(tk1))
    all_var.append(copy.deepcopy(tk2))
    all_var += copy.deepcopy(x)
    all_var += copy.deepcopy(y)
    end_values = copy.deepcopy(y)

    return begin_values, end_values, all_var, statement


def __mb_mode1(cd, round_inf):
    statement = ""
    statement1 = ""
    begin_values = list()
    end_values = list()

    if cd["scenario"] == "RK":
        begin_values, end_values, all_var, key_values, statement1 = related_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var)
        for i in range(1, cd["mul"]):
            statement += xor_operate(key_values[0][0], key_values[0][i], ["0bin{}".format(cd["k1_{}".format(i)][j]) for j in range(0, len(cd["k1_{}".format(i)]))], cd["mode"][1])
        for i in range(1, cd["mul"]):
            statement += xor_operate(key_values[1][0], key_values[1][i], ["0bin{}".format(cd["k2_{}".format(i)][j]) for j in range(0, len(cd["k2_{}".format(i)]))], cd["mode"][1])

    elif cd["scenario"] == "SK":
        begin_values, end_values, all_var, statement1 = single_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var)

    else:
        print("The scenario is invalid.")

    for i in range(1, cd["mul"]):
        statement += xor_operate(begin_values[0], begin_values[i], ["0bin{}".format(cd["b{}".format(i)][j]) for j in range(0, len(cd["b{}".format(i)]))], cd["mode"][1])

    statement += statement1

    for i in range(1, cd["mul"]):
        statement += xor_operate(end_values[0], end_values[i], ["0bin{}".format(cd["e{}".format(i)][j]) for j in range(0, len(cd["e{}".format(i)]))], cd["mode"][1])

    statement += trailer([], [])

    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __mb_mode1(cd, round_inf)
