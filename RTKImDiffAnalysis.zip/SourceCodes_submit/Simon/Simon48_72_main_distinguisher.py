#!/usr/bin/python
# -*- coding: UTF-8 -*-

import copy
import Simon_family_model
import time
import os

if __name__ == "__main__":

    cd = dict()

    cd["cipher_name"] = "simon48_72"

    cd["mul"] = 2
    cd["block_size"] = 24
    cd["word_size"] = 24
    cd["key_words"] = 3
    cd["key_size"] = 72
    cd["const_seq"] = 0

    cd["scenario"] = "SK"
    cd["mode"] = ["ID", "detail"]

    folder = cd["cipher_name"] + "_{}way_{}_diff_zc_record".format(cd["mul"], cd["mode"][0])

    if not os.path.exists(folder):
        os.mkdir(folder)

    # search_space = list()
    # for i in range(0, cd["block_size"]):
    #     b1 = [0 for b1_i in range(0, cd["block_size"])]
    #     b2 = [0 for b2_i in range(0, cd["block_size"])]
    #     b1[i] = 1
    #     for j in range(0, cd["block_size"]):
    #         e1 = [0 for e1_j in range(0, cd["block_size"])]
    #         e2 = [0 for e2_j in range(0, cd["block_size"])]
    #         e1[j] = 1
    #         search_space.append(copy.deepcopy([b1, b2, e1, e2]))
    #         search_space.append(copy.deepcopy([b2, b1, e1, e2]))
    #         search_space.append(copy.deepcopy([b1, b2, e2, e1]))
    #         search_space.append(copy.deepcopy([b2, b1, e2, e1]))

    position_space = list()
    for i in range(0, 32):
        position_space.append([copy.deepcopy(i)])

    round_i = 12
    cd["position_rou"] = 0
    cd["record_file"] = folder + "////" + cd["cipher_name"] + "_record_{}.txt".format(cd["mode"])
    cd["time_record"] = folder + "////" + cd["cipher_name"] + "_time_record_{}.txt".format(cd["mode"])
    cd["result_file"] = folder + "////" + cd["cipher_name"] + "_result_record_{}.txt".format(cd["mode"])
    total_search = len(position_space)
    ttt1 = time.time()

    cd["bl1"] = copy.deepcopy([0 for i in range(16)])
    cd["br1"] = copy.deepcopy([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1])
    cd["el1"] = copy.deepcopy([0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0])
    cd["er1"] = copy.deepcopy([0 for i in range(16)])

    while cd["position_rou"] < round_i:
        cd["solve_file"] = folder + "////" + cd["cipher_name"] + "_round{}.stp".format(round_i)
        t1 = time.time()
        distinguish_find = False
        search_count = 0

        for s in position_space:
            cd["position"] = copy.deepcopy(s)
            mode = [cd["mode"], [0, round_i]]
            t11 = time.time()
            Simon_family_model.model_build(cd, mode)
            flag, res = Simon_family_model.solver(cd["solve_file"])
            search_count += 1
            t22 = time.time()
            print(t22 - t11)
            if flag:
                rf = open(cd["record_file"], "a")
                rf.write("*" * 20)
                rf.write("{}round impossible {}way distinguisher found in round{} with contradiction in {}\n".format(
                    round_i, cd["mul"], cd["position_rou"], cd["position"])
                )
                rf.write("when the values:\n")
                rf.write("bl = {}\n".format(str(cd["bl1"])))
                rf.write("br = {}\n".format(str(cd["br1"])))
                rf.write("el = {}\n".format(str(cd["el1"])))
                rf.write("er = {}\n".format(str(cd["er1"])))
                rf.write("lp = {}\n".format(str(cd["position"])))
                rf.close()
                statement = Simon_family_model.parsing_result(res, round_i, cd)
                file = open(cd["result_file"], "a")
                file.write("*" * 20)
                file.write("{}round impossible {}way distinguisher found in round{} with contradiction in {}\n".format(
                    round_i, cd["mul"], cd["position_rou"], cd["position"])
                )
                file.write(statement)
                file.close()
                distinguish_find = True
                break
            else:
                print("testing: position = {}\nround = {}, search = {}, total_search = {}.".format(
                    cd["position"], cd["position_rou"], search_count, total_search))

        t2 = time.time()
        tf = open(cd["time_record"], "a")
        if distinguish_find:
            tf.write("After " + str(t2 - t1) + "time, we found {} rounds impossible differential with contradiction in round{}.\n\n".format(round_i, cd["position_rou"]))
        else:
            tf.write("After " + str(t2 - t1) + "time, we show no {} round impossible differential with contradiction in round{}.\n\n".format(round_i, cd["position_rou"]))
            cd["position_rou"] += 1
        tf.close()