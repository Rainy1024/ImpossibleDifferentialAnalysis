#!/usr/bin/python
# -*- coding: UTF-8 -*-


import copy
import os
import subprocess


z = [[1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1,
      0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0],
     [1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1,
      0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0],
     [1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0,
      0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1],
     [1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0,
      0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1],
     [1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1,
      0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1]]


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def xor_operate(var1, var2, var3):
    xor_statement = ""
    for var_index in range(0, len(var1)):
        xor_statement += __xor_operate_1(var1[var_index], var2[var_index], var3[var_index])
    return xor_statement


def __left_circular_shift(var, rot_num, word_size):
    m = rot_num % word_size
    var1 = copy.deepcopy(var[m:word_size] + var[0:m])
    return var1


def __right_circular_shift(var, rot_num, word_size):
    m = (word_size - rot_num) % word_size
    var1 = copy.deepcopy(var[m:word_size] + var[0:m])
    return var1


def bit_wise_and_func(var_in, var_out, mul):
    subcommand = ""
    for m in range(0, mul):
        var1 = __left_circular_shift(var_in[m], 1, len(var_in[m]))
        var2 = __left_circular_shift(var_in[m], 8, len(var_in[m]))
        for i in range(0, len(var_out[m])):
            subcommand += "ASSERT({} = {} & {});\n".format(var_out[m][i], var1[i], var2[i])
    return subcommand


def bit_wise_xor_func4(var_l, var_r, var_t, var_k, var_out, mul):
    subcommand = ""
    for m in range(0, mul):
        var = __left_circular_shift(var_l[m], 2, len(var_l[m]))
        for i in range(0, len(var_out[m])):
            subcommand += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, {}))));\n".format(
              var_out[m][i], var_k[i], var[i], var_t[m][i], var_r[m][i]
            )
    return subcommand


def key_expansion_func(key_in, key_out, rou, size, j):
    subcommand = ""
    var1 = __right_circular_shift(key_in[size-1], 3, len(key_in[size-1]))
    if size == 4:
        for jj in range(len(var1)):
            var1[jj] = "BVXOR({}, {})".format(var1[jj], key_in[size-3][jj])

    var2 = __right_circular_shift(var1, 1, len(var1))
    for index in range(0, len(key_out)):
        ziv = "0bin{}".format((z[j][(rou-size) % 62] >> (len(key_out)-1-index)) & 0x1)
        civ = "0bin{}".format((3 >> (len(key_out)-1-index)) & 0x1)
        subcommand += "ASSERT({} = BVXOR(~{}, BVXOR({}, BVXOR({}, BVXOR({}, {})))));\n".format(
            key_out[index], key_in[0][index], ziv, civ, var2[index], var1[index]
        )
    return subcommand


def __constraint_func(var_inl, var_inr, var_outl, var_outr, values):
    subcommand = ""
    for i in range(len(var_inl[0])):
        if i in values:
            subcommand += "ASSERT(BVXOR({}, BVXOR({}, BVXOR({}, {}))) = 0bin0);\n".format(
                var_inl[0][i], var_inl[1][i], var_outl[0][i], var_outl[1][i]
            )
        elif (i+len(var_inl[0])) in values:
            subcommand += "ASSERT(BVXOR({}, BVXOR({}, BVXOR({}, {}))) = 0bin0);\n".format(
                var_inr[0][i], var_inr[1][i], var_outr[0][i], var_outr[1][i]
            )
    return subcommand


def var_value_assign(var, values):
    statement = ""
    for i in range(0, len(var)):
        statement += "ASSERT({} = 0bin{});\n".format(var[i], values[i])
    return statement


def var_equal(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(0, len(var_in[m])):
            statement += "ASSERT({} = {});\n".format(var_out[m][i], var_in[m][i])
    return statement


def header(var1):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR(1);\n"
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, round_index, var_size, mul):
    var = [["p{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var


def key_var_dec(var, round_index, var_size):
    return ["{}_{}_{}".format(var, round_index, i) for i in range(0, var_size)]


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver1(solve_file):
    stp_parameters = ["stp", "--cryptominisat", "--thread", "20", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def getStringForNonZero(variables):
    command = "ASSERT(("
    for var in variables:
        command += var + "|"
    command = command[:-1]
    command += ") = 0bin1);\n"
    return command


def values_propagate_phrase(cd, round_inf):
    command = ""
    all_var = list()
    begin_values = list()
    end_values = list()
    x = state_var_dec("x", 0, cd["block_size"], cd["mul"])
    y = state_var_dec("y", 0, cd["block_size"], cd["mul"])
    begin_values.append(copy.deepcopy(x))
    begin_values.append(copy.deepcopy(y))

    for rou in range(round_inf[0], round_inf[1]):
        all_var += copy.deepcopy(x)
        all_var += copy.deepcopy(y)
        k = key_var_dec("k", rou, cd["block_size"])
        all_var.append(copy.deepcopy(k))
        z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        if rou >= cd["key_words"]:
            key_values = list()
            for i in range(cd["key_words"]):
                kk = key_var_dec("k", rou-(cd["key_words"]-i), cd["block_size"])
                key_values.append(kk)
            command += key_expansion_func(key_values, k, rou, cd["key_words"], cd["const_seq"])

        command += bit_wise_and_func(x, z, cd["mul"])
        x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
        y1 = state_var_dec("y", rou+1, cd["block_size"], cd["mul"])
        if (rou+1) == round_inf[2]:
            xt = state_var_dec("xt", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(xt)
            yt = state_var_dec("yt", rou, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(yt)
            command += bit_wise_xor_func4(x, y, z, k, xt, cd["mul"])
            command += var_equal(x, yt, cd["mul"])
            command += __constraint_func(xt, yt, x1, y1, cd["position"])
        else:
            command += bit_wise_xor_func4(x, y, z, k, x1, cd["mul"])
            command += var_equal(x, y1, cd["mul"])
        x = copy.deepcopy(x1)
        y = copy.deepcopy(y1)

    all_var += copy.deepcopy(x)
    all_var += copy.deepcopy(y)
    end_values.append(copy.deepcopy(x))
    end_values.append(copy.deepcopy(y))

    return begin_values, end_values, all_var, command


def constraint_func(x, y, positions, values):
    subcommand = ""
    for i in range(len(x[0])):
        if i in positions:
            subcommand += "ASSERT(BVXOR({}, {}) = 0bin{});\n".format(
                x[0][i], x[1][i], values[0]
            )
            subcommand += "ASSERT(BVXOR({}, {}) = 0bin{});\n".format(
                x[2][i], x[3][i], values[1]
            )
        elif (i + len(x[0])) in positions:
            subcommand += "ASSERT(BVXOR({}, {}) = 0bin{});\n".format(
                y[0][i], y[1][i], values[0]
            )
            subcommand += "ASSERT(BVXOR({}, {}) = 0bin{});\n".format(
                y[2][i], y[3][i], values[1]
            )
    return subcommand


def __model_build_func(cd, round_inf):
    statement = ""
    begin_values, end_values, all_var, statement1 = values_propagate_phrase(cd, round_inf)

    statement += header(all_var)

    for i in range(1, cd["mul"]):
        statement += xor_operate(
            begin_values[0][0], begin_values[0][i], ["0bin{}".format(cd["bl{}".format(i)][j]) for j in range(0, len(cd["bl{}".format(i)]))]
        )

    for i in range(1, cd["mul"]):
        statement += xor_operate(
            begin_values[1][0], begin_values[1][i], ["0bin{}".format(cd["br{}".format(i)][j]) for j in range(0, len(cd["br{}".format(i)]))]
        )

    statement += statement1

    for i in range(1, cd["mul"]):
        statement += xor_operate(
            end_values[0][0], end_values[0][i], ["0bin{}".format(cd["el{}".format(i)][j]) for j in range(0, len(cd["el{}".format(i)]))]
        )

    for i in range(1, cd["mul"]):
        statement += xor_operate(
            end_values[1][0], end_values[1][i], ["0bin{}".format(cd["er{}".format(i)][j]) for j in range(0, len(cd["er{}".format(i)]))]
        )

    statement += trailer([], [])

    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __model_build_func(cd, round_inf)

