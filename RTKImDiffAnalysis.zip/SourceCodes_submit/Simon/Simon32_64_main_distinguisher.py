#!/usr/bin/python
# -*- coding: UTF-8 -*-

import copy
import Simon_family_model
import time
import math
import os

if __name__ == "__main__":

    cd = dict()
    cd["cipher_name"] = "simon32_64"

    cd["mul"] = 2
    cd["block_size"] = 16
    cd["word_size"] = 16
    cd["key_words"] = 4
    cd["key_size"] = 64
    cd["const_seq"] = 0
    cd["scenario"] = "SK"
    cd["mode"] = ["ID", "detail"]

    cd["flag"] = "distinguish"
    folder1 = cd["cipher_name"] + "_{}_{}".format(cd["flag"], cd["mode"][0])
    if not os.path.exists(folder1):
        os.mkdir(folder1)

    position_space = list()
    for i in range(0, 32):
        position_space.append([copy.deepcopy(i)])

    search_space = list()
    for i in range(0, 2 * cd["block_size"]):
        bl = [0 for bi in range(0, cd["block_size"])]
        br = [0 for bj in range(0, cd["block_size"])]
        if i < cd["block_size"]:
            bl[i] = 1
        else:
            br[i-cd["block_size"]] = 1
        for j in range(0, 2 * cd["block_size"]):
            el = [0 for ei in range(0, cd["block_size"])]
            er = [0 for ej in range(0, cd["block_size"])]
            if j < cd["block_size"]:
                el[j] = 1
            else:
                er[j - cd["block_size"]] = 1
            search_space.append(copy.deepcopy([bl, br, el, er]))

    folder = folder1 + "////" + cd["cipher_name"] + "_{}_{}way_distinguisher".format(cd["scenario"], cd["mul"])
    if not os.path.exists(folder):
        os.mkdir(folder)

    cd["record_file"] = folder + "////" + cd["cipher_name"] + "_record_{}.txt".format(cd["scenario"])
    cd["search_log"] = folder + "////" + cd["cipher_name"] + "_search_{}.txt".format(cd["scenario"])
    cd["structure_record"] = folder + "////" + cd["cipher_name"] + "_structure_{}.txt".format(cd["scenario"])
    total_search = len(search_space)
    index_space = list()
    distinguish_find = True
    begin_round = 0
    end_round = 11
    while distinguish_find:
        distinguish_find = False
        round_i = list()
        a = math.ceil((begin_round + 1 + end_round) / 2)
        if ((begin_round + 1 + end_round) % 2) == 0:
            round_i.append(copy.deepcopy(a))
            round_i.append(copy.deepcopy(a-1))
            round_i.append(copy.deepcopy(a+1))
        else:
            round_i.append(copy.deepcopy(a))
            round_i.append(copy.deepcopy(a-1))
        search_count = 0
        while search_count < len(search_space):
            cd["bl1"] = copy.deepcopy(search_space[search_count][0])
            cd["br1"] = copy.deepcopy(search_space[search_count][1])
            cd["el1"] = copy.deepcopy(search_space[search_count][2])
            cd["er1"] = copy.deepcopy(search_space[search_count][3])
            for index in range(0, len(round_i)):
                cd["solve_file"] = folder + "////" + cd["cipher_name"] + "_round{}_{}_{}.stp".format(begin_round, end_round, round_i[index])
                for p in position_space:
                    cd["position"] = copy.deepcopy(p)
                    round_inf = [begin_round, end_round, round_i[index]]
                    t11 = time.time()
                    Simon_family_model.model_build(cd, round_inf)
                    flag = Simon_family_model.solver(cd["solve_file"])
                    t22 = time.time()
                    print(t22 - t11)
                    if flag:
                        rf = open(cd["record_file"], "a")
                        rf.write("*" * 20)
                        rf.write("{} round impossible distinguish was found.\n".format(end_round))
                        rf.write("with the contraction in round {} position {}.\n".format(round_i[index], cd["position"]))
                        rf.write("when the values:\n")
                        rf.write("bl = {}\n".format(str(cd["bl1"])))
                        rf.write("br = {}\n".format(str(cd["br1"])))
                        rf.write("el = {}\n".format(str(cd["el1"])))
                        rf.write("er = {}\n".format(str(cd["er1"])))
                        rf.close()
                        distinguish_find = True
                        break
                    else:
                        sf = open(cd["search_log"], "a")
                        sf.write("*" * 20)
                        sf.write("testing:\ntime = {}, round = {}_{}, search_count = {}, total_search = {}\n".format(t22 - t11, begin_round, end_round, search_count+1, total_search))
                        sf.write("contraction round = {}, position = {}\n".format(round_i[index], cd["position"]))
                        sf.close()
                        print("testing: round = {}_{}, search_count = {}, total_search = {}".format(begin_round, end_round, search_count+1, total_search))
                        print("round_i = {}, position = {}\n".format(round_i[index], cd["position"]))
                if distinguish_find:
                    break
            if distinguish_find:
                index_space.append(search_count)
                break
            else:
                search_count += 1

        if distinguish_find:
            end_round += 1
