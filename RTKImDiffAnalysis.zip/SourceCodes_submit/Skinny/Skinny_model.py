#!/usr/bin/python
# -*- coding: UTF-8 -*-

import subprocess
import os
import copy

sbox_4bit = [0xc, 0x6, 0x9, 0x0, 0x1, 0xa, 0x2, 0xb, 0x3, 0x8, 0x5, 0xd, 0x4, 0xe, 0x7, 0xf]
sbox_8bit = [0x65, 0x4c, 0x6a, 0x42, 0x4b, 0x63, 0x43, 0x6b, 0x55, 0x75, 0x5a, 0x7a, 0x53, 0x73, 0x5b, 0x7b, 0x35, 0x8c,\
             0x3a, 0x81, 0x89, 0x33, 0x80, 0x3b, 0x95, 0x25, 0x98, 0x2a, 0x90, 0x23, 0x99, 0x2b, 0xe5, 0xcc, 0xe8, 0xc1,\
             0xc9, 0xe0, 0xc0, 0xe9, 0xd5, 0xf5, 0xd8, 0xf8, 0xd0, 0xf0, 0xd9, 0xf9, 0xa5, 0x1c, 0xa8, 0x12, 0x1b, 0xa0,\
             0x13, 0xa9, 0x05, 0xb5, 0x0a, 0xb8, 0x03, 0xb0, 0x0b, 0xb9, 0x32, 0x88, 0x3c, 0x85, 0x8d, 0x34, 0x84, 0x3d,\
             0x91, 0x22, 0x9c, 0x2c, 0x94, 0x24, 0x9d, 0x2d, 0x62, 0x4a, 0x6c, 0x45, 0x4d, 0x64, 0x44, 0x6d, 0x52, 0x72,\
             0x5c, 0x7c, 0x54, 0x74, 0x5d, 0x7d, 0xa1, 0x1a, 0xac, 0x15, 0x1d, 0xa4, 0x14, 0xad, 0x02, 0xb1, 0x0c, 0xbc,\
             0x04, 0xb4, 0x0d, 0xbd, 0xe1, 0xc8, 0xec, 0xc5, 0xcd, 0xe4, 0xc4, 0xed, 0xd1, 0xf1, 0xdc, 0xfc, 0xd4, 0xf4,\
             0xdd, 0xfd, 0x36, 0x8e, 0x38, 0x82, 0x8b, 0x30, 0x83, 0x39, 0x96, 0x26, 0x9a, 0x28, 0x93, 0x20, 0x9b, 0x29,\
             0x66, 0x4e, 0x68, 0x41, 0x49, 0x60, 0x40, 0x69, 0x56, 0x76, 0x58, 0x78, 0x50, 0x70, 0x59, 0x79, 0xa6, 0x1e,\
             0xaa, 0x11, 0x19, 0xa3, 0x10, 0xab, 0x06, 0xb6, 0x08, 0xba, 0x00, 0xb3, 0x09, 0xbb, 0xe6, 0xce, 0xea, 0xc2,\
             0xcb, 0xe3, 0xc3, 0xeb, 0xd6, 0xf6, 0xda, 0xfa, 0xd3, 0xf3, 0xdb, 0xfb, 0x31, 0x8a, 0x3e, 0x86, 0x8f, 0x37,\
             0x87, 0x3f, 0x92, 0x21, 0x9e, 0x2e, 0x97, 0x27, 0x9f, 0x2f, 0x61, 0x48, 0x6e, 0x46, 0x4f, 0x67, 0x47, 0x6f,\
             0x51, 0x71, 0x5e, 0x7e, 0x57, 0x77, 0x5f, 0x7f, 0xa2, 0x18, 0xae, 0x16, 0x1f, 0xa7, 0x17, 0xaf, 0x01, 0xb2,\
             0x0e, 0xbe, 0x07, 0xb7, 0x0f, 0xbf, 0xe2, 0xca, 0xee, 0xc6, 0xcf, 0xe7, 0xc7, 0xef, 0xd2, 0xf2, 0xde, 0xfe,\
             0xd7, 0xf7, 0xdf, 0xff]
tweakey_permutation = [9, 15, 8, 13, 10, 14, 12, 11, 0, 1, 2, 3, 4, 5, 6, 7]
permutation = [0, 1, 2, 3, 7, 4, 5, 6, 10, 11, 8, 9, 13, 14, 15, 12]
MC = [[1, 0, 1, 1], [1, 0, 0, 0], [0, 1, 1, 0], [1, 0, 1, 0]]


def header(var1, size):
    temp1 = ""
    for var in var1:
        temp = var[0]
        for i in range(1, len(var)):
            temp += ", {}".format(var[i])
        temp += " : BITVECTOR({});\n".format(size)
        temp1 += temp
    return temp1


def trailer(v1, va2):
    return "QUERY(FALSE);\nCOUNTEREXAMPLE;"


def state_var_dec(var, round_index, var_size, mul):
    var0 = [["p{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_key_var_dec(var, var_size, mul):
    var0 = [["k{}_{}_{}".format(j, var, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def related_round_key_var_dec(var, round_index, var_size, mul):
    var0 = [["k{}_{}_{}_{}".format(j, var, round_index, i) for i in range(0, var_size)] for j in range(0, mul)]
    return var0


def single_key_var_dec(var, var_size):
    var0 = ["k_{}_{}".format(var, j) for j in range(0, var_size)]
    return var0


def single_round_key_var_dec(var, round_index, var_size):
    var0 = ["k_{}_{}_{}".format(var, round_index, j) for j in range(0, var_size)]
    return var0


def solver(solve_file):
    stp_parameters = ["stp", "--minisat", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def solver1(solve_file):
    stp_parameters = ["stp", "--cryptominisat", "--thread", "6", "--CVC", solve_file]
    res = subprocess.check_output(stp_parameters)
    res = res.decode().replace("\r", "")[0:-1]
    print(res)
    if res == "Valid.":
        return True
    else:
        return False


def __xor_operate_1(var1, var2, var3):
    return "ASSERT(BVXOR({}, {}) = {});\n".format(var1, var2, var3)


def __xor_operate_branch(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        if var_out[var_index] == "0bin0000":
            xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
        else:
            xor_statement += "ASSERT((BVXOR({0}, {1}))[3:3]|(BVXOR({0}, {1}))[2:2]|(BVXOR({0}, {1}))[1:1]|(BVXOR({0}, {1}))[0:0] = 0bin1);\n".format(var_in1[var_index], var_in2[var_index])
    return xor_statement


def __xor_operate_detail(var_in1, var_in2, var_out):
    xor_statement = ""
    for var_index in range(0, len(var_in1)):
        xor_statement += __xor_operate_1(var_in1[var_index], var_in2[var_index], var_out[var_index])
    return xor_statement


def xor_operate(var1, var2, values, mode):
    if mode == "branch":
        return __xor_operate_branch(var1, var2, values)
    elif mode == "detail":
        return __xor_operate_detail(var1, var2, values)
    else:
        print("Input format error!")


def perm_wire_in(var1, perm):
    var = ["" for ii in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[i] = var1[perm[i]]
    return var


def perm_wire_out(var1, perm):
    var = ["" for ii in range(0, len(var1))]
    for i in range(0, len(var1)):
        var[perm[i]] = var1[i]
    return var


def generate_round_contants_func(round_inf):
    init_rc = [0 for i in range(6)]
    temp_rc = [0 for j in range(6)]
    rc = list()
    for i in range(round_inf[0], round_inf[1]+1):
        temp_rc[5] = init_rc[1] ^ init_rc[0] ^ 1
        for j in range(0, 5):
            temp_rc[j] = init_rc[j+1]
        init_rc = copy.copy(temp_rc)

        c0 = int(str(temp_rc[2]) + str(temp_rc[3]) + str(temp_rc[4]) + str(temp_rc[5]), 2)
        c1 = int("00" + str(temp_rc[0]) + str(temp_rc[1]), 2)
        c2 = 2
        rc_state = [0 for c in range(16)]
        rc_state[0] = c0
        rc_state[4] = c1
        rc_state[8] = c2
        rc.append(copy.deepcopy(rc_state))
    return rc


def __tweakey1_schedule(var_in, var_out, PT):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, PT))
    for i in range(len(var_in)):
        statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def __tweakey2_4bits_schedule(var_in, var_out, PT):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, PT))
    for i in range(len(var_in)):
        if i <= 7:
            statement += "ASSERT({0} = {1}[2:2]@{1}[1:1]@{1}[0:0]@(BVXOR({1}[3:3], {1}[2:2])));\n".format(var_out[i], var[i])
        else:
            statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def __tweakey2_8bits_schdeule(var_in, var_out, PT):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, PT))

    for i in range(len(var_in)):
        if i <= 7:
            statement += "ASSERT({0} = {1}[6:6]@{1}[5:5]@{1}[4:4]@{1}[3:3]@{1}[2:2]@{1}[1:1]@{1}[0:0]@(BVXOR({1}[7:7], {1}[5:5])));\n".format(var_out[i], var[i])
        else:
            statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def __tweakey3_4bits_schedule(var_in, var_out, PT):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, PT))
    for i in range(len(var_in)):
        if i <= 7:
            statement += "ASSERT({0} = (BVXOR({1}[0:0], {1}[3:3]))@{1}[3:3]@{1}[2:2]@{1}[1:1]);\n".format(var_out[i], var[i])
        else:
            statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def __tweakey3_8bits_schedule(var_in, var_out, PT):
    statement = ""
    var = copy.deepcopy(perm_wire_in(var_in, PT))
    for i in range(len(var_in)):
        if i <= 7:
            statement += "ASSERT({0} = (BVXOR({1}[0:0],{1}[6:6]))@{1}[7:7]@{1}[6:6]@{1}[5:5]@{1}[4:4]@{1}[3:3]@{1}[2:2]@{1}[1:1]);\n".format(var_out[i], var[i])
        else:
            statement += "ASSERT({} = {});\n".format(var_out[i], var[i])
    return statement


def related_tweakeys_schedule(tweakeys_in, tweakeys_out, PT, size, mul):
    statement = ""
    for i in range(1, len(tweakeys_in)+1):
        for m in range(0, mul):
            if i == 1:
                statement += __tweakey1_schedule(tweakeys_in[0][m], tweakeys_out[0][m], PT)
            elif i == 2:
                if size == 4:
                    statement += __tweakey2_4bits_schedule(tweakeys_in[1][m], tweakeys_out[1][m], PT)
                else:
                    statement += __tweakey2_8bits_schdeule(tweakeys_in[1][m], tweakeys_out[1][m], PT)
            elif i == 3:
                if size == 4:
                    statement += __tweakey3_4bits_schedule(tweakeys_in[2][m], tweakeys_out[2][m], PT)
                else:
                    statement += __tweakey3_8bits_schedule(tweakeys_in[2][m], tweakeys_out[2][m], PT)
            else:
                print("The number of tweakey is invalid,")
    return statement


def __sbox_operate_4bits(var_in, var_out, sbox):
    statement1 = "0bin1100"
    for i in range(1, 16):
        iv = "0bin"
        for j1 in range(0, 4):
            iv += "{}".format((i >> (3-j1)) & 0x1)
        siv = "0bin"
        for j in range(0, 4):
            siv += "{}".format((sbox[i] >> (3-j)) & 0x1)
        statement1 = "(IF {} = {} THEN {} ELSE {} ENDIF)".format(var_in, iv, siv, statement1)
    statement = "ASSERT({} = {});\n".format(var_out, statement1)
    return statement


def __sbox_operate_8bits(var_in, var_out, sbox):
    statement1 = "0bin01100101"
    for i in range(1, 256):
        iv = "0bin"
        for j in range(0, 8):
            iv += "{}".format((i >> (7 - j)) & 0x1)
        siv = "0bin"
        for j in range(0, 8):
            siv += "{}".format((sbox[i] >> (7 - j)) & 0x1)
        statement1 = "(IF {} = {} THEN {} ELSE {} ENDIF)".format(var_in, iv, siv, statement1)
    statement = "ASSERT({} = {});\n".format(var_out, statement1)
    return statement


def subcells_operation(var_in, var_out, size, mul):
    statement = ""
    if size == 4:
        sbox = copy.deepcopy(sbox_4bit)
        for m in range(0, mul):
            for i in range(0, len(var_in[m])):
                statement += __sbox_operate_4bits(var_in[m][i], var_out[m][i], sbox)
    elif size == 8:
        sbox = copy.deepcopy(sbox_8bit)
        for m in range(0, mul):
            for i in range(0, len(var_in[m])):
                statement += __sbox_operate_8bits(var_in[m][i], var_out[m][i], sbox)
    return statement


def __add_constants_tweakey1(var_in, var_out, contants, tweakey1, size):
    statement = ""
    var = copy.deepcopy(perm_wire_out(var_out, permutation))
    for i in range(0, len(var_in)):
        iv = "0bin"
        for j in range(0, size):
            iv += "{}".format((contants[i] >> (size-1-j)) & 0x1)
        if i < 8:
            statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var[i], tweakey1[i], iv, var_in[i])
        else:
            statement += "ASSERT({} = BVXOR({}, {}));\n".format(var[i], var_in[i], iv)
    return statement


def __add_constants_tweakey2(var_in, var_out, contants, tweakey1, tweakey2, size):
    statement = ""
    var = copy.deepcopy(perm_wire_out(var_out, permutation))
    for i in range(0, len(var_in)):
        iv = "0bin"
        for j in range(0, size):
            iv += "{}".format((contants[i] >> (size-1-j)) & 0x1)
        if i < 8:
            statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, {}))));\n".format(
                var[i], tweakey2[i], tweakey1[i], iv, var_in[i]
            )
        else:
            statement += "ASSERT({} = BVXOR({}, {}));\n".format(var[i], var_in[i], iv)
    return statement


def __add_constants_tweakey3(var_in, var_out, contants, tweakey1, tweakey2, tweakey3, size):
    statement = ""
    var = copy.deepcopy(perm_wire_out(var_out, permutation))
    for i in range(0, len(var_in)):
        iv = "0bin"
        for j in range(0, size):
            iv += "{}".format((contants[i] >> (size-1-j)) & 0x1)
        if i < 8:
            statement += "ASSERT({} = BVXOR({}, BVXOR({}, BVXOR({}, BVXOR({}, {})))));\n".format(var[i], tweakey3[i], tweakey2[i], tweakey1[i], iv, var_in[i])
        else:
            statement += "ASSERT({} = BVXOR({}, {}));\n".format(var[i], var_in[i], iv)
    return statement


def related_add_constants_and_tweakeys_operation(var_in, var_out, constants, tweakeys, size, mul):
    statement = ""
    for m in range(0, mul):
        if len(tweakeys) == 1:
            statement += __add_constants_tweakey1(var_in[m], var_out[m], constants, tweakeys[0][m], size)
        elif len(tweakeys) == 2:
            statement += __add_constants_tweakey2(var_in[m], var_out[m], constants, tweakeys[0][m], tweakeys[1][m], size)
        elif len(tweakeys) == 3:
            statement += __add_constants_tweakey3(var_in[m], var_out[m], constants, tweakeys[0][m], tweakeys[1][m], tweakeys[2][m], size)
        else:
            print("Error tweakeys!")
    return statement


def mixcolumns_operation(var_in, var_out, mul):
    statement = ""
    for m in range(0, mul):
        for i in range(0, len(var_in[m])):
            if i in {0, 1, 2, 3}:
                statement += "ASSERT({} = BVXOR({}, BVXOR({}, {})));\n".format(var_out[m][i], var_in[m][i], var_in[m][i+8], var_in[m][i+12])
            elif i in {4, 5, 6, 7}:
                statement += "ASSERT({} = {});\n".format(var_out[m][i], var_in[m][i-4])
            elif i in {8, 9, 10, 11}:
                statement += "ASSERT({} = BVXOR({}, {}));\n".format(var_out[m][i], var_in[m][i-4], var_in[m][i])
            else:
                statement += "ASSERT({} = BVXOR({}, {}));\n".format(var_out[m][i], var_in[m][i-12], var_in[m][i-4])
    return statement


def __constraint_func(var_in, var_out, positions, mul):
    statement = ""
    for m in range(0, mul):
        for i in positions:
            statement += "ASSERT(BVXOR({}, {}) = 0bin0000);\n".format(
                var_in[m][i], var_out[m][i]
            )
    return statement


def __constraint_func_or(var_in, var_out, values, mul):
    statement = ""
    for m in range(1, mul):
        tmp = "ASSERT(0bin0000"
        for i in range(len(var_in[0])):
            if i in values:
                tmp += "|(BVXOR({}, BVXOR({}, BVXOR({}, {}))))".format(var_in[0][i], var_in[m][i], var_out[0][i], var_out[m][i])
        tmp += " = 0bin0000);\n"
        statement += tmp
    return statement


def related_key_state_propagate_phrase(cd, round_inf):
    statement = ""
    all_var = list()
    tweakeys = list()
    RC = generate_round_contants_func(round_inf)

    x = state_var_dec("x", round_inf[0], cd["block_size"], cd["mul"])
    tk1 = related_round_key_var_dec("tk1", round_inf[0], cd["block_size"], cd["mul"])
    tk2 = related_round_key_var_dec("tk2", round_inf[0], cd["block_size"], cd["mul"])
    tk3 = related_round_key_var_dec("tk3", round_inf[0], cd["block_size"], cd["mul"])

    for i in range(1, cd["z"]+1):
        if i == 1:
            tweakeys.append(tk1)
        elif i == 2:
            tweakeys.append(tk2)
        else:
            tweakeys.append(tk3)

    begin_values = copy.deepcopy(x)
    key_values = copy.deepcopy(tweakeys)

    for rou in range(round_inf[0], round_inf[1]):
        for i in range(0, cd["z"]):
            all_var += copy.deepcopy(tweakeys[i])

        all_var += copy.deepcopy(x)
        y = state_var_dec("y", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(y)
        z = state_var_dec("z", rou, cd["block_size"], cd["mul"])
        all_var += copy.deepcopy(z)

        statement += related_add_constants_and_tweakeys_operation(x, y, RC[rou], tweakeys, cd["sbox_size"], cd["mul"])
        statement += mixcolumns_operation(y, z, cd["mul"])
        x1 = state_var_dec("x", rou+1, cd["block_size"], cd["mul"])
        if (rou+1) == round_inf[2]:
            w = state_var_dec("w", rou+1, cd["block_size"], cd["mul"])
            all_var += copy.deepcopy(w)
            statement += subcells_operation(z, w, cd["sbox_size"], cd["mul"])
            if cd["flag"] == "contraction":
                statement += __constraint_func(w, x1, cd["positions"], cd["mul"])
            else:
                statement += __constraint_func_or(w, x1, cd["positions"], cd["mul"])
        else:
            statement += subcells_operation(z, x1, cd["sbox_size"], cd["mul"])
        x = copy.deepcopy(x1)

        tweakeys1 = list()
        tk11 = related_round_key_var_dec("tk1", rou+1, cd["block_size"], cd["mul"])
        tk22 = related_round_key_var_dec("tk2", rou+1, cd["block_size"], cd["mul"])
        tk33 = related_round_key_var_dec("tk3", rou+1, cd["block_size"], cd["mul"])
        for i in range(1, cd["z"] + 1):
            if i == 1:
                tweakeys1.append(tk11)
            elif i == 2:
                tweakeys1.append(tk22)
            else:
                tweakeys1.append(tk33)

        statement += related_tweakeys_schedule(tweakeys, tweakeys1, tweakey_permutation, cd["sbox_size"], cd["mul"])
        tweakeys = copy.deepcopy(tweakeys1)

    y = state_var_dec("y", round_inf[1], cd["block_size"], cd["mul"])
    statement += related_add_constants_and_tweakeys_operation(x, y, RC[round_inf[1]], tweakeys, cd["sbox_size"], cd["mul"])
    for i in range(0, cd["z"]):
        all_var += copy.deepcopy(tweakeys[i])
    all_var += copy.deepcopy(x)
    all_var += copy.deepcopy(y)
    end_values = copy.deepcopy(y)

    return begin_values, end_values, all_var, key_values, statement


def __mb_mode1(cd, round_inf):
    statement = ""
    statement1 = ""
    begin_values = list()
    end_values = list()

    if cd["scenario"] == "RK":
        begin_values, end_values, all_var, key_values, statement1 = related_key_state_propagate_phrase(cd, round_inf)
        statement += header(all_var, cd["sbox_size"])
        for index in range(0, len(key_values)):
            for i in range(1, cd["mul"]):
                statement += xor_operate(key_values[index][0], key_values[index][i], cd["k{}_{}".format(index+1, i)], cd["mode"][1])
    else:
        print("The scenario is invalid.")

    for i in range(1, cd["mul"]):
        statement += xor_operate(begin_values[0], begin_values[i], cd["b{}".format(i)], cd["mode"][1])

    statement += statement1

    for i in range(1, cd["mul"]):
        statement += xor_operate(end_values[0], end_values[i], cd["e{}".format(i)], cd["mode"][1])

    statement += trailer([], [])

    f = open(cd["solve_file"], "a")
    f.write(statement)
    f.close()


def model_build(cd, round_inf):
    if os.path.exists(cd["solve_file"]):
        os.remove(cd["solve_file"])
    if cd["mode"][0] == "ID":
        __mb_mode1(cd, round_inf)


