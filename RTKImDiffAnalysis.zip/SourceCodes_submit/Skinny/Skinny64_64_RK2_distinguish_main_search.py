#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
search impossible differential
"""

import copy
import Skinny_model
import time
import math
import os

if __name__ == "__main__":

    parameters = dict()

    parameters["mul"] = 2
    parameters["cipher_name"] = "SKinny64_64"
    parameters["cipher_size"] = 64
    parameters["key_size"] = 64
    parameters["sbox_size"] = 4
    parameters["sbox_num"] = 16
    parameters["block_size"] = 16
    parameters["size"] = 4
    parameters["z"] = 1
    parameters["scenario"] = "RK"
    parameters["mode"] = ["ID", "detail"]

    parameters["flag"] = "contraction"
    folder1 = parameters["cipher_name"] + "_{}_{}".format(parameters["flag"], parameters["mode"][0])
    if not os.path.exists(folder1):
        os.mkdir(folder1)

    search_space = list()
    for i1 in range(0, 16):
        b1 = ["0bin0000" for b1_i in range(0, parameters["block_size"])]
        for val in range(1, 16):
            iv = "0bin"
            for i2 in range(0, 4):
                iv += "{}".format((val >> (3 - i2)) & 0x1)
            b1[i1] = iv
            b2 = ["0bin0000" for b2_i in range(0, parameters["block_size"])]
            search_space.append(copy.deepcopy([b1, b2]))

    folder = folder1 + "////" + parameters["cipher_name"] + "_{}_{}way_prove".format(parameters["scenario"], parameters["mul"])
    if not os.path.exists(folder):
        os.mkdir(folder)

    parameters["record_file"] = folder + "////" + parameters["cipher_name"] + "_record_{}.txt".format(parameters["scenario"])
    parameters["search_log"] = folder + "////" + parameters["cipher_name"] + "_search_{}.txt".format(parameters["scenario"])
    parameters["time_record"] = folder + "////" + parameters["cipher_name"] + "_time_{}.txt".format(parameters["scenario"])
    total_search = len(search_space)
    distinguish_find = True
    begin_round = 0
    distinguish_rounds = 10
    while distinguish_find:
        distinguish_find = False
        end_round = begin_round + distinguish_rounds
        round_i = list()
        a = math.ceil((begin_round + 1 + end_round) / 2)
        if ((begin_round + 1 + end_round) % 2) == 0:
            round_i.append(copy.deepcopy(a))
            round_i.append(copy.deepcopy(a-1))
            round_i.append(copy.deepcopy(a+1))
        else:
            round_i.append(copy.deepcopy(a))
            round_i.append(copy.deepcopy(a-1))
        search_count = 0
        t1 = time.time()
        while search_count < len(search_space):
            parameters["k1_1"] = copy.deepcopy(search_space[search_count][0])
            parameters["b1"] = copy.deepcopy(search_space[search_count][1])
            parameters["e1"] = copy.deepcopy(search_space[search_count][1])
            t3 = time.time()
            for index in range(0, len(round_i)):
                parameters["solve_file"] = folder + "////" + parameters["cipher_name"] + "_round{}_{}_{}.stp".format(begin_round, end_round, round_i[index])
                for p in range(0, 16):
                    parameters["positions"] = copy.deepcopy([p])
                    round_inf = [begin_round, end_round, round_i[index]]
                    t11 = time.time()
                    Skinny_model.model_build(parameters, round_inf)
                    flag = Skinny_model.solver(parameters["solve_file"])
                    t22 = time.time()
                    print(t22 - t11)
                    if flag:
                        rf = open(parameters["record_file"], "a")
                        rf.write("*" * 20)
                        rf.write("{} round impossible distinguish was found.\n".format(distinguish_rounds))
                        rf.write("with the contraction in round {} position {}.\n".format(round_i[index], parameters["positions"]))
                        rf.write("when the values:\n")
                        rf.write("b1 = {}\n".format(str(parameters["b1"])))
                        rf.write("e1 = {}\n".format(str(parameters["e1"])))
                        rf.write("k1_1 = {}\n".format(str(parameters["k1_1"])))
                        rf.close()
                        distinguish_find = True
                        break
                    else:
                        print("testing: round = {}_{}, search_count = {}, total_search = {}".format(
                            begin_round, end_round, search_count, total_search))
                        print("round_i = {}, position = {}\n".format(round_i[index], parameters["positions"]))
                if distinguish_find:
                    break
            t4 = time.time()
            sf = open(parameters["search_log"], "a")
            sf.write("*" * 20)
            sf.write("testing:\ntime = {}, round = {}_{}, search_count = {}, total_search = {}\n".format(
                t4 - t3, begin_round, end_round, search_count, total_search))
            sf.close()
            if distinguish_find:
                break
            else:
                search_count += 1

        t2 = time.time()
        tf = open(parameters["time_record"], "a")
        if distinguish_find:
            tf.write("After " + str(t2 - t1) + "time, we found {} rounds impossible differential.\n\n".format(distinguish_rounds))
            distinguish_rounds += 1
        else:
            tf.write("After " + str(t2 - t1) + "time, we show no {} round impossible differential.\n\n".format(distinguish_rounds))
        tf.close()




