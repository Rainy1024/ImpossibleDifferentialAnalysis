#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
search impossible differential
"""

import copy
import Skinny_model
import time
import math
import os

if __name__ == "__main__":

    parameters = dict()

    parameters["mul"] = 2
    parameters["cipher_name"] = "SKinny64_128"
    parameters["cipher_size"] = 64
    parameters["key_size"] = 128
    parameters["sbox_size"] = 4
    parameters["sbox_num"] = 16
    parameters["block_size"] = 16
    parameters["size"] = 4
    parameters["z"] = 2
    parameters["scenario"] = "RK"
    parameters["mode"] = ["ID", "detail"]

    parameters["flag"] = "distinguish"
    folder1 = parameters["cipher_name"] + "_{}_{}_p1".format(parameters["flag"], parameters["mode"][0])
    if not os.path.exists(folder1):
        os.mkdir(folder1)

    search_space = list()
    for i1 in range(0, 16):
        b1 = ["0bin0000" for b1_i in range(0, parameters["block_size"])]
        b2 = ["0bin0000" for b2_i in range(0, parameters["block_size"])]
        for val1 in (1, 16):
            iv1 = "0bin"
            for i2 in range(0, 4):
                iv1 += "{}".format((val1 >> (3 - i2)) & 0x1)
            b1[i1] = iv1
            for val2 in range(1, 16):
                iv2 = "0bin"
                for i4 in range(0, 4):
                    iv2 += "{}".format((val2 >> (3 - i4)) & 0x1)
                b2[i1] = iv2
                e1 = ["0bin0000" for e1_i in range(0, parameters["block_size"])]
                search_space.append(copy.deepcopy([b1, b2, e1]))

    folder = folder1 + "////" + parameters["cipher_name"] + "_{}_{}way_all".format(parameters["scenario"], parameters["mul"])
    if not os.path.exists(folder):
        os.mkdir(folder)

    parameters["record_file"] = folder + "////" + parameters["cipher_name"] + "_record_{}.txt".format(parameters["scenario"])
    parameters["search_log"] = folder + "////" + parameters["cipher_name"] + "_search_{}.txt".format(parameters["scenario"])
    parameters["time_record"] = folder + "////" + parameters["cipher_name"] + "_time_{}.txt".format(parameters["scenario"])
    total_search = len(search_space)
    distinguish_find = True
    begin_round = 0
    distinguish_rounds = 11
    while distinguish_find:
        distinguish_find = False
        end_round = begin_round + distinguish_rounds
        search_count = 0
        t1 = time.time()
        while search_count < len(search_space):
            parameters["k1_1"] = copy.deepcopy(search_space[search_count][0])
            parameters["k2_1"] = copy.deepcopy(search_space[search_count][1])
            parameters["b1"] = copy.deepcopy(search_space[search_count][2])
            parameters["e1"] = copy.deepcopy(search_space[search_count][2])
            parameters["solve_file"] = folder + "////" + parameters["cipher_name"] + "_round{}_{}.stp".format(begin_round, end_round)

            round_inf = [begin_round, end_round, 0]
            t11 = time.time()
            Skinny_model.model_build(parameters, round_inf)
            flag = Skinny_model.solver(parameters["solve_file"])
            t22 = time.time()
            print(t22 - t11)
            if flag:
                rf = open(parameters["record_file"], "a")
                rf.write("*" * 20)
                rf.write("{} round impossible distinguish was found.\n".format(distinguish_rounds))
                rf.write("when the values:\n")
                rf.write("b1 = {}\n".format(str(parameters["b1"])))
                rf.write("e1 = {}\n".format(str(parameters["e1"])))
                rf.write("k1_1 = {}\n".format(str(parameters["k1_1"])))
                rf.write("k2_1 = {}\n".format(str(parameters["k2_1"])))
                rf.close()
                distinguish_find = True
                break
            else:
                search_count += 1
                sf = open(parameters["search_log"], "a")
                sf.write("*" * 20)
                sf.write("testing:\ntime = {}, round = {}_{}, search_count = {}, total_search = {}\n".format(
                    t22 - t11, begin_round, end_round, search_count, total_search))
                sf.close()
                print("testing: round = {}_{}, search_count = {}, total_search = {}".format(
                    begin_round, end_round, search_count, total_search))

        t2 = time.time()
        tf = open(parameters["time_record"], "a")
        if distinguish_find:
            tf.write("After " + str(t2 - t1) + "time, we found {} rounds impossible differential.\n\n".format(distinguish_rounds))
            distinguish_rounds += 1
        else:
            tf.write("After " + str(t2 - t1) + "time, we show no {} round impossible differential.\n\n".format(distinguish_rounds))
        tf.close()




